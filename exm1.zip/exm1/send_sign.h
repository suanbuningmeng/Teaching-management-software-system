#ifndef SEND_SIGN_H
#define SEND_SIGN_H

#include <QWidget>
#include <vector>
#include <map>
using namespace std;
#include <QSqlQuery>
#include <QSqlRecord>
#include <QMessageBox>
#include <QSqlTableModel>
#include <QDateTime>
#include <QDebug>
#include <QWidget>
#include <QSqlDatabase>
#include "db.h"

#include <QTcpSocket>
#include <QTcpServer>

#include <QSqlError>
#include "teacher_choose.h"

namespace Ui {
class send_sign;
}

class send_sign : public QWidget
{
    Q_OBJECT

public:
    explicit send_sign(QWidget *parent = nullptr);
    ~send_sign();

private slots:
    void on_Absence_list_clicked();
    void Init();
    void Item_Change();
    void on_start_sign_clicked();

    void on_refresh_clicked();

    void on_returnbutton_clicked();

signals:
     void sign_time(QString time);

private:
    Ui::send_sign *ui;
    QString t_name;
    QSqlDatabase db;


    QString choosepaperid,choosestudent;//记录抽取试卷信息
    vector<int>     number;        //记录主观题试卷题目序号
    vector<QString> questions; //记录主观题编号
    vector<QString> values;    //记录分值
    vector<QString> studentsofexam;//记录发布考试涉及的学生

};

#endif // SEND_SIGN_H
