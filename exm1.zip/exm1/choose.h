#ifndef CHOOSE_H
#define CHOOSE_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtSql>
#include <QMessageBox>
#include "db.h"
#include <QHostAddress>
#include <vector>
#include <map>

using namespace std;
namespace Ui {
class choose;
}

class choose : public QWidget
{
    Q_OBJECT


private slots:

     void Init();

     void on_selectbutton_clicked();

     void on_deletebutton_clicked();

     void on_closebutton_clicked();

     void on_refresh_clicked();

     void on_pushButton_2_clicked();

public:
    explicit choose(QWidget *parent = nullptr);
    ~choose();

private:
    Ui::choose *ui;
    QSqlDatabase db;


    QSqlRelationalTableModel *tabModelSCourse;
    QItemSelectionModel *theSelectionSCourse;

    QSqlTableModel *tabModelAdmin;
    QItemSelectionModel *theSelectionAdmin;

    QString t_name;

    void openTable();
};

#endif // CHOOSE_H
