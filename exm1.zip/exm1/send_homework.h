#ifndef SEND_HOMEWORK_H
#define SEND_HOMEWORK_H

#include <vector>
#include <map>
using namespace std;
#include <QSqlQuery>
#include <QSqlRecord>
#include <QMessageBox>
#include <QSqlTableModel>
#include <QDateTime>
#include <QDebug>
#include <QWidget>
#include <QSqlDatabase>

#include <QTcpSocket>
#include <QTcpServer>

#include <QSqlError>

#include "db.h"

namespace Ui {
class send_homework;
}

class send_homework : public QWidget
{
    Q_OBJECT

public:
    explicit send_homework(QWidget *parent = nullptr);
    ~send_homework();

private slots:
    void Init();

    void on_startbutton_clicked();

    void on_set_homeworkbutton_clicked();

private:
    Ui::send_homework *ui;
    QString t_name;
    QSqlDatabase db;


    QString choosepaperid,choosestudent;//记录抽取试卷信息
    vector<int>     number;        //记录主观题试卷题目序号
    vector<QString> questions; //记录主观题编号
    vector<QString> values;    //记录分值
    vector<QString> studentsofexam;//记录发布考试涉及的学生

    map<QString,QTcpSocket*> sockets;//记录tcp连接和学生对应关系
    QTcpServer *server;
    int id;//记录当前展示的是第几题
};

#endif // SEND_HOMEWORK_H
