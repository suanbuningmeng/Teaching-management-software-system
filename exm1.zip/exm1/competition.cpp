#include "competition.h"
#include "ui_competition.h"

competition::competition(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::competition)
{
    ui->setupUi(this);
    setWindowTitle("竞赛与学术");
    Init();
}

competition::~competition()
{
    delete ui;
}

void competition::Init()
{

    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }

    QSqlQuery query;
    QString sql;
    query.prepare("SELECT id,name FROM student WHERE id=:ID");
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();
    _name =query.value("name").toString();//获取名字
    ui->lineEdit_id->setText(LoginId);
    ui->lineEdit_name->setText(_name);

      qDebug()<<_name
             <<LoginId;
}
void competition::on_pushButton_clicked()
{
    QSqlQuery query;
    QString sql;
    QString str="未通过";

    QString award=ui->textEdit_Award->toPlainText();
    QString compete=ui->textEdit_Compet->toPlainText();
    QString communicate=ui->textEdit_change->toPlainText();

    sql = QString("insert into stuInfo (id,name,Award,Competition,academic_exchange,Approved) values ('%1','%2','%3','%4','%5','未通过');"
                  ).arg(LoginId).arg(_name).arg(award).arg(compete).arg(communicate);
    if(query.exec(sql))
    {
        QMessageBox::information(this,"提示","竞赛填报成功");
    }
    else
    {
               QMessageBox::warning(this,"错误","错误信息\n"
                                    +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
               qDebug()<<db.lastError().text();
    }
}
void competition::on_pushButton_2_clicked()
{
    ui->textEdit_Award->clear();
    ui->textEdit_Compet->clear();
    ui->textEdit_change->clear();
}
