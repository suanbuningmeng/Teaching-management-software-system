#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <QSqlDatabase>  //连接数据库
#include <QSqlQuery>
#include <QMessageBox>   //消息框
#include <QDebug>
#include "db.h"          //导入数据库头文件
#include "teacher_choose.h"  //导入老师登入界面
#include "student.h"  //导入学生登入界面
#include "admin.h"    //导入管理员登入界面
#include "account_register.h"   //导入账号注册界面


namespace Ui {
class Page_login;
}

class Page_login : public QWidget
{
    Q_OBJECT

public:
    explicit Page_login(QWidget *parent = nullptr);
    ~Page_login();

    //连接数据库
    bool database_connection();

    //匹配登陆信息
    bool match_name_password(QString ID,QString PASSWORD,QString table);

private slots:
    void on_registerbutton_clicked();

    void on_loginbutton_clicked();


    void on_studebutton_toggled(bool checked);

    void on_teachbutton_toggled(bool checked);

    void on_adminbutton_toggled(bool checked);

signals:
    void sendLoginSuccess();

private:
    Ui::Page_login *ui;
    QSqlDatabase db;
};

#endif // PAGE_LOGIN_H
