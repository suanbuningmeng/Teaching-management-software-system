#ifndef DB_H
#define DB_H
#include <QString>
extern QString DB_HOSTNAME;
extern QString DB_USERNAME;
extern QString DB_PASSWORD;
extern QString DB_NAME;

extern QString LoginId;     //存放老师学生的ID

#endif // DB_H
