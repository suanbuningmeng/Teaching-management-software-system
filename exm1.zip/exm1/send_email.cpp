#include "send_email.h"
#include "ui_send_email.h"
#include "base64.h"
#include "db.h"

send_email::send_email(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::send_email)
{
    ui->setupUi(this);
    setWindowTitle("邮件");
    Init();
}

send_email::~send_email()
{
    delete ui;
}

void send_email::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::information(this,"提示","链接数据库失败");
    }
    ui->user_Edit->setText("19956340077@163.com");
    ui->pass_Edit->setText("QZWMHTZJMNVXLHEH");

    ui->form_Edi->setText("19956340077@163.com");
    ui->subject_Edit->setText("通知");
}


//单发消息
void send_email::on_pushButton_2_clicked()
{
    if(ui->user_Edit->text().isEmpty()||ui->pass_Edit->text().isEmpty()|| ui->form_Edi->text().isEmpty()||ui->receive_edit->text().isEmpty()||ui->subject_Edit->text().isEmpty())
    {
    QMessageBox::warning(this,"警告","请填写完整信息");
        return;
    }
    QString ip;
 if(ui->qqbutton->isChecked())
 {
    ip = "smtp.qq.com";
 }
 if(ui->wybutton->isChecked())
 {
    ip = "smtp.163.com";
 }
    send_EMail(ui->user_Edit->text().toStdString(),
               ui->pass_Edit->text().toStdString(),
               ui->form_Edi->text().toStdString(),
               ui->receive_edit->text().toStdString(),
               ui->subject_Edit->text().toStdString(),
               ui->textEdit->toPlainText().toStdString(),//获取文本信息和ip服务器地址信息
               ip.toStdString()
               );
    QMessageBox::information(this,"提示","发送成功！");
}

void send_email::on_send_student_clicked()
{
    QSqlQuery query;//  query 集合
    query.prepare("SELECT email,identify FROM email_form");//把邮箱和身份选出来
    query.exec();
    if(query.size()<1)
    {
         QMessageBox::information(this,"提示","没找到邮箱");
         return;
    }
    //query.first();//指向第一条
    while(query.next())//从头指向尾
    {
        QString Email;


        if(query.value("identify").toString()=="老师" || query.value("email").isNull()||query.value("identify").isNull() )
            continue;  //如果是老师或者邮箱是空的则直接跳过，指针指向下一条记录

        Email=query.value("email").toString();

        ui->receive_edit->setText(Email);
        QString ip;
     if(ui->qqbutton->isChecked())
     {
        ip = "smtp.qq.com";
     }
     if(ui->wybutton->isChecked())
     {
        ip = "smtp.163.com";
     }
        send_EMail(ui->user_Edit->text().toStdString(),
                   ui->pass_Edit->text().toStdString(),
                   ui->form_Edi->text().toStdString(),
                   ui->receive_edit->text().toStdString(),
                   ui->subject_Edit->text().toStdString(),
                   ui->textEdit->toPlainText().toStdString(),//获取文本信息和ip服务器地址信息
                   ip.toStdString()
                   );
        //ui->receive_edit->text().clear();
    }
    QMessageBox::warning(this,"提示","学生邮件发送成功");
}


void send_email::on_send_teacher_clicked()
{
    QSqlQuery query;
    query.prepare("SELECT email,identify FROM email_form");//把邮箱和身份选出来
    query.exec();
    if(query.size()<1)
    {
         QMessageBox::information(this,"提示","没找到邮箱");
         return;
    }
   // query.first();//指向第一条

    while(query.next())//从头指向尾
    {
        QString Email;

//            if(query.value("identify").toString()=="学生" || query.value("email").isNull()||query.value("identify").isNull() )
//                continue;  //如果是老师或者邮箱是空的则直接跳过，指针指向下一条记录
       // qDebug()<< query.value("identify").toString();

        if(query.value("identify").toString()=="老师")
        {
            qDebug()<< query.value("identify").toString();
            Email=query.value("email").toString();

            ui->receive_edit->setText(Email);


            QString ip;
         if(ui->qqbutton->isChecked())
         {
            ip = "smtp.qq.com";
         }
         if(ui->wybutton->isChecked())
         {
            ip = "smtp.163.com";
         }
            send_EMail(ui->user_Edit->text().toStdString(),
                       ui->pass_Edit->text().toStdString(),
                       ui->form_Edi->text().toStdString(),
                       ui->receive_edit->text().toStdString(),
                       ui->subject_Edit->text().toStdString(),
                       ui->textEdit->toPlainText().toStdString(),//获取文本信息和ip服务器地址信息
                       ip.toStdString()
                       );
        }

        // ui->receive_edit->clear();
    }
    QMessageBox::warning(this,"提示","老师邮件发送成功");

}

