#ifndef TEACHER_CHOOSE_H
#define TEACHER_CHOOSE_H

#include <QWidget>
#include "send_homework.h"  //发布作业
#include "send_sign.h"      //发布签到
#include "teacher.h"        //老师管理学生界面
#include "correct_homework.h"        //作业批改界面
#include "teacheraccount.h"    //账号管理界面
#include "send_email_ts.h"   //发送邮件界面
#include "question.h"  //答疑与辅导界面
#include <QNetworkInterface>


namespace Ui {
class teacher_choose;
}

class teacher_choose : public QWidget
{
    Q_OBJECT

public:
    explicit teacher_choose(QWidget *parent = nullptr);
    ~teacher_choose();

private slots:
    void on_sendhomeworkbutton_clicked();

    void on_signinbutton_clicked();

    void on_managebutton_clicked();

    void on_markhomework_clicked();

    void on_accountbutton_clicked();

    void on_emailbutton_clicked();

    void on_questionbutton_clicked();

private:
    QString t_name;
    Ui::teacher_choose *ui;
    QSqlDatabase db;
};

#endif // TEACHER_CHOOSE_H
