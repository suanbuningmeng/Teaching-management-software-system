#include "mainwindow.h"
#include "page_login.h"
#include <QApplication>
#include "stusql.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Page_login w;
    w.show();//登录窗口
    return a.exec();//进入应用程序的事件循环，等待用户进行操作,使得页面一直显示
}
