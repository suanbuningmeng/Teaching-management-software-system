#ifndef EDIT_HOMEWORK_H
#define EDIT_HOMEWORK_H

#include <QWidget>
#include "send_homework.h"
#include "db.h"

namespace Ui {
class edit_homework;
}

class edit_homework : public QWidget
{
    Q_OBJECT

public:
    explicit edit_homework(QWidget *parent = nullptr);
    ~edit_homework();
    void on_questionpushButton_clicked();

private slots:
    void on_newpushButton_clicked();


    void on_search_button_clicked();

    void on_next_page_clicked();


    void on_delet_page_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private slots:
     void Init();

     void on_returnbutton_clicked();

private:
    Ui::edit_homework *ui;
    QSqlDatabase db;
};

#endif // EDIT_HOMEWORK_H
