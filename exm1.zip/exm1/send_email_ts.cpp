#include "send_email_ts.h"
#include "ui_send_email_ts.h"
#include "base64.h"
#include "db.h"

send_email_ts::send_email_ts(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::send_email_ts)
{
    ui->setupUi(this);
    setWindowTitle("邮件");
    Init();
}

send_email_ts::~send_email_ts()
{
    delete ui;
}

void send_email_ts::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::information(this,"提示","链接数据库失败");
    }
    QSqlQuery query;
    query.prepare("SELECT email,name FROM email_form WHERE id=:ID");//在email_form找到姓名和邮件信息
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();
    QString email;
    QString name;
    email =query.value("email").toString();
    name =query.value("name").toString();
    ui->user_Edit->setText(name);
    ui->form_Edi->setText(email);
    ui->subject_Edit->setText("通知");
}

//单发消息
void send_email_ts::on_pushButton_2_clicked()
{
    if(ui->user_Edit->text().isEmpty()||ui->pass_Edit->text().isEmpty()|| ui->form_Edi->text().isEmpty()||ui->receive_edit->text().isEmpty()||ui->subject_Edit->text().isEmpty())
    {
    QMessageBox::warning(this,"警告","请填写完整信息");
        return;
    }
    QString ip;
    if(ui->qqbutton->isChecked())
    {
       ip = "smtp.qq.com";
    }
    if(ui->wybutton->isChecked())
    {
       ip = "smtp.163.com";
    }
       send_EMail(ui->user_Edit->text().toStdString(),
                  ui->pass_Edit->text().toStdString(),
                  ui->form_Edi->text().toStdString(),
                  ui->receive_edit->text().toStdString(),
                  ui->subject_Edit->text().toStdString(),
                  ui->textEdit->toPlainText().toStdString(),//获取文本信息和ip服务器地址信息
                  ip.toStdString()
                  );
    QMessageBox::information(this,"提示","发送成功！");
}
