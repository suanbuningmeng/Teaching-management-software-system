#ifndef EMAIL_H
#define EMAIL_H
#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;
#include <WinSock2.h>
#include <QDebug>
#include "base64.h"

void send_EMail( string _Username, string _Password,string _From,string _receive,string _Suject,string _Text,string _ip);
#endif // EMAIL_H
