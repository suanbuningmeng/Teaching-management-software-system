#include "send_sign.h"
#include "ui_send_sign.h"

send_sign::send_sign(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::send_sign)
{
    ui->setupUi(this);
    setWindowTitle("发布签到");
    connect(ui->subject_box,SIGNAL(currentIndexChanged(QString)),this,SLOT(Item_Change()));//将字符变化的事件，与某函数连接
    Item_Change();
    Init();
}

send_sign::~send_sign()
{
    delete ui;
}

void send_sign::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");

    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
    QString sql;
    QSqlQuery query;
    vector<QString> subjects;//科目列表
    vector<QString> students;//学生列表

//根据登录id  确定名字
   sql = QString("select * from teacher where id = '%1';").arg(LoginId);

   if(query.exec(sql))
   {
       query.first();
       t_name=query.value("name").toString();
   }
   query.clear();

   ui->subject_box->clear();  //清空科目

      sql = QString("select * from course where teacher = '%1';").arg(t_name);


    if(query.exec(sql))
    {
        while(query.next())
        {
            subjects.push_back(query.value(1).toString());
            qDebug()<<query.value(1).toString();
        }
    }

    int n = subjects.size();
    for(int i = 0; i < n ; ++i)
    {
        ui->subject_box->addItem(subjects[i]);//把签到科目加上去
    }
}


void send_sign::on_Absence_list_clicked()
{
     QString sql;
     QSqlQuery query;
     QString str="未签到";
     query.prepare("SELECT s.name,e.Attend_Status,e.sid,e.cid from scourse e,student s,course c"
        " where e.sid=s.id and c.id=e.cid and c.teacher=:teach_name and c.name=:ke_name and e.Attend_Status=:Absence");//根据老师名和课程名找到学生信息

     query.bindValue(":teach_name",t_name);

     query.bindValue(":ke_name",ui->subject_box->currentText());

     query.bindValue(":Absence",str);
     if(!query.exec())
     {
         qDebug()<<"error";
     }
         query.first();//直接指向结果集的第一条
         QSqlQueryModel *c_model = new QSqlQueryModel;
         c_model->setQuery(query);
         c_model->setHeaderData(0,Qt::Horizontal,"姓名");
         c_model->setHeaderData(1,Qt::Horizontal,"出勤");
         c_model->setHeaderData(2,Qt::Horizontal,"学号");
         c_model->setHeaderData(3,Qt::Horizontal,"课程号");
         ui->tableView->setModel(c_model);
}



void send_sign::on_start_sign_clicked()
{

    QString sql;
    QSqlQuery query,query1;
    vector<QString> students;//学生列表

    QString stu_name;//学生名字
    QString stu_Id;   //学生id
    QString attend_status;//出勤状态
    QString course_Id;   //课程id

    QString str="未签到";

    query.prepare("SELECT s.name,e.Attend_Status,e.sid,e.cid from scourse e,student s,course c"//选共同点
       " where e.sid=s.id and c.id=e.cid and c.teacher=:teach_name and c.name=:ke_name");//根据老师的姓名和课程名找到学生的姓名，出勤，id

    query.bindValue(":teach_name",t_name);

    query.bindValue(":ke_name",ui->subject_box->currentText());

    if(!query.exec())
    {
        qDebug()<<"error";
    }
    while(query.next())  //先把学生、名字、出勤选出来
    {
    stu_name=query.value("name").toString();
    stu_Id=query.value("sid").toString();
    attend_status=query.value("Attend_Status").toString();
    course_Id=query.value("cid").toString();

    sql = QString("update scourse set Attend_Status= '%1' where sid = '%2' and cid = '%3';"

                  ).arg(str).arg(stu_Id).arg(course_Id);

    if(!query1.exec(sql))
    {
        qDebug()<<"error";
        return;
    }
    }
    QMessageBox::information(this,"提示","发起签到成功");

    Init();
    Item_Change();
}

void  send_sign::Item_Change()
{
    QString sql;
    QSqlQuery query;
    vector<QString> students;//学生列表


    query.prepare("SELECT s.name,e.Attend_Status,e.sid,e.cid from scourse e,student s,course c"//选共同点
       " where e.sid=s.id and c.id=e.cid and c.teacher=:teach_name and c.name=:ke_name");

    query.bindValue(":teach_name",t_name);
    query.bindValue(":ke_name",ui->subject_box->currentText());
    if(!query.exec())
    {
        qDebug()<<"error";
    }
    while(query.next())
    {
        students.push_back(query.value("name").toString());
    }

    query.first();//直接指向结果集的第一条
    QSqlQueryModel *c_model = new QSqlQueryModel;
    c_model->setQuery(query);
    c_model->setHeaderData(0,Qt::Horizontal,"姓名");
    c_model->setHeaderData(1,Qt::Horizontal,"出勤");
    c_model->setHeaderData(2,Qt::Horizontal,"学号");
    c_model->setHeaderData(3,Qt::Horizontal,"课程号");
    ui->tableView->setModel(c_model);
//主要是测试用，方便查看试卷发给谁了
}

void send_sign::on_refresh_clicked()
{
     Item_Change();
}

void send_sign::on_returnbutton_clicked()
{
    this->hide();
}
