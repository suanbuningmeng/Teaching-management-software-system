#ifndef ADMIN_H
#define ADMIN_H

#include <QWidget>

#include <QMainWindow>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtSql>
#include <QMessageBox>
#include <QSqlQueryModel>

#include "db.h"
#include "send_email.h" //邮件

namespace Ui {
class admin;
}

class admin : public QWidget
{
    Q_OBJECT

public:
    explicit admin(QWidget *parent = nullptr);
    ~admin();

private slots:
    void on_addbutton_clicked();//添加信息按钮

    void on_delbutton_clicked();//删除信息按钮

    void on_findbutton_clicked();//lineEdit信号槽函数

    void getCurrChanged(int);//tabWidget信号槽函数

    void on_topbutton_clicked();//升序按钮

    void on_lowbutton_clicked();//降序按钮

    void on_emailbutton_clicked();//邮件按钮

    void on_savebutton_clicked();

private:
    Ui::admin *ui;

    QSqlDatabase db;

    QSqlTableModel *tabModelStudent;
    QItemSelectionModel *theSelectionStudent;

    QSqlTableModel *tabModelTeacher;
    QItemSelectionModel *theSelectionTeacher;

    QSqlTableModel *tabModelCourse;
    QItemSelectionModel *theSelectionCourse;

    QSqlTableModel *tabModelAdmin;
    QItemSelectionModel *theSelectionAdmin;

    QSqlTableModel *tabModelEmail;
    QItemSelectionModel *theSelectionEmail;

    QSqlTableModel *tabModelstu_info;
    QItemSelectionModel *theSelectionstu_info;

    void openTable();

};

#endif // ADMIN_H
