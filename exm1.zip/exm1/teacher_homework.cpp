#include "teacher_homework.h"
#include "ui_teacher_homework.h"

teacher_homework::teacher_homework(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::teacher_homework)
{
    ui->setupUi(this);
}

teacher_homework::~teacher_homework()
{
    delete ui;
}
