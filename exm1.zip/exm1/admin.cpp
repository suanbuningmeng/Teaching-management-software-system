#include "admin.h"
#include "ui_admin.h"

#include <QStandardItemModel>

admin::admin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::admin)
{
    ui->setupUi(this);
    setWindowTitle("管理员");
    this->setAttribute(Qt::WA_DeleteOnClose);//关闭时释放内存

    ui->studenview->setSelectionBehavior(QAbstractItemView::SelectItems);
    ui->studenview->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->studenview->setAlternatingRowColors(true);

    ui->teacherview->setSelectionBehavior(QAbstractItemView::SelectItems);
    ui->teacherview->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->teacherview->setAlternatingRowColors(true);

    ui->courseview->setSelectionBehavior(QAbstractItemView::SelectItems);
    ui->courseview->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->courseview->setAlternatingRowColors(true);

    ui->emailview->setSelectionBehavior(QAbstractItemView::SelectItems);
    ui->emailview->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->emailview->setAlternatingRowColors(true);

    ui->stuinfoview->setSelectionBehavior(QAbstractItemView::SelectItems);
    ui->stuinfoview->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->stuinfoview->setAlternatingRowColors(true);

    ui->tabWidget->setCurrentIndex(0);

    ui->comboBox->addItem("学号");
    ui->comboBox->addItem("姓名");

    ui->searchcombobox->addItem("精确查找");
    ui->searchcombobox->addItem("模糊查找");

    db=QSqlDatabase::addDatabase("QMYSQL");

    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);

    connect(ui->lineEdit,SIGNAL(textChanged(QString)),this,SLOT(on_findbutton_clicked()));//当lineEdit有字符变化时发出信号
    connect(ui->tabWidget, SIGNAL(currentChanged(int)), SLOT(getCurrChanged(int)));//当tabWidet切换发出信号


    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
    openTable();

}

void admin::openTable()
{
    //学生表
    tabModelStudent=new QSqlTableModel(this,db);
    tabModelStudent->setTable("student");
    tabModelStudent->setEditStrategy(QSqlTableModel::OnManualSubmit);//
    if(!(tabModelStudent->select()))
    {
        QMessageBox::critical(this,"错误","打开数据表错误,错误信息\n"
                              +tabModelStudent->lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    tabModelStudent->setHeaderData(tabModelStudent->fieldIndex("id"),Qt::Horizontal,"学号");
    tabModelStudent->setHeaderData(tabModelStudent->fieldIndex("name"),Qt::Horizontal,"姓名");
    tabModelStudent->setHeaderData(tabModelStudent->fieldIndex("sex"),Qt::Horizontal,"性别");
    tabModelStudent->setHeaderData(tabModelStudent->fieldIndex("institute"),Qt::Horizontal,"院系");
    tabModelStudent->setHeaderData(tabModelStudent->fieldIndex("age"),Qt::Horizontal,"年龄");
    tabModelStudent->setHeaderData(tabModelStudent->fieldIndex("password"),Qt::Horizontal,"密码");

    theSelectionStudent=new QItemSelectionModel(tabModelStudent);

    ui->studenview->setModel(tabModelStudent);
    ui->studenview->setSelectionModel(theSelectionStudent);


    //课程信息表
    tabModelCourse=new QSqlTableModel(this,db);
    tabModelCourse->setTable("course");
    tabModelCourse->setEditStrategy(QSqlTableModel::OnManualSubmit);
    if(!(tabModelCourse->select()))
    {
        QMessageBox::critical(this,"错误","打开数据表错误,错误信息\n"
                              +tabModelCourse->lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    tabModelCourse->setHeaderData(tabModelCourse->fieldIndex("id"),Qt::Horizontal,"课程号");
    tabModelCourse->setHeaderData(tabModelCourse->fieldIndex("name"),Qt::Horizontal,"课程名");
    tabModelCourse->setHeaderData(tabModelCourse->fieldIndex("teacher"),Qt::Horizontal,"任课老师");
    tabModelCourse->setHeaderData(tabModelCourse->fieldIndex("credit"),Qt::Horizontal,"学分");
    tabModelCourse->setHeaderData(tabModelCourse->fieldIndex("institute"),Qt::Horizontal,"开课院系");

    theSelectionCourse=new QItemSelectionModel(tabModelCourse);

    ui->courseview->setModel(tabModelCourse);
    ui->courseview->setSelectionModel(theSelectionCourse);

    //老师信息表
    tabModelTeacher=new QSqlTableModel(this,db);
    tabModelTeacher->setTable("teacher");
    tabModelTeacher->setEditStrategy(QSqlTableModel::OnManualSubmit);
    if(!(tabModelTeacher->select()))
    {
        QMessageBox::critical(this,"错误","打开数据表错误,错误信息\n"
                              +tabModelTeacher->lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    tabModelTeacher->setHeaderData(tabModelTeacher->fieldIndex("id"),Qt::Horizontal,"工号");
    tabModelTeacher->setHeaderData(tabModelTeacher->fieldIndex("name"),Qt::Horizontal,"姓名");
    tabModelTeacher->setHeaderData(tabModelTeacher->fieldIndex("password"),Qt::Horizontal,"密码");

    //教学评估
    tabModelTeacher->setHeaderData(tabModelTeacher->fieldIndex("remark"),Qt::Horizontal,"教学评估");

    theSelectionTeacher=new QItemSelectionModel(tabModelTeacher);

    ui->teacherview->setModel(tabModelTeacher);
    ui->teacherview->setSelectionModel(theSelectionTeacher);

    //选课表
    tabModelAdmin=new QSqlTableModel(this,db);
    tabModelAdmin->setTable("scourse");
    tabModelAdmin->setEditStrategy(QSqlTableModel::OnManualSubmit);
    if(!(tabModelAdmin->select()))
    {
        QMessageBox::critical(this,"错误","打开数据表错误,错误信息\n"
                              +tabModelAdmin->lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    tabModelAdmin->setHeaderData(tabModelAdmin->fieldIndex("cid"),Qt::Horizontal,"课程号");
    tabModelAdmin->setHeaderData(tabModelAdmin->fieldIndex("sid"),Qt::Horizontal,"学号");
    tabModelAdmin->setHeaderData(tabModelAdmin->fieldIndex("grade"),Qt::Horizontal,"成绩");
    tabModelAdmin->setHeaderData(tabModelAdmin->fieldIndex("credit"),Qt::Horizontal,"绩点");
    tabModelAdmin->setHeaderData(tabModelAdmin->fieldIndex("absence"),Qt::Horizontal,"缺勤次数");
    tabModelAdmin->setHeaderData(tabModelAdmin->fieldIndex("Attend_Status"),Qt::Horizontal,"签到情况");

    theSelectionAdmin=new QItemSelectionModel(tabModelAdmin);

    ui->chooseview->setModel(tabModelAdmin);
    ui->chooseview->setSelectionModel(theSelectionAdmin);

    //邮箱信息表
    tabModelEmail=new QSqlTableModel(this,db);
    tabModelEmail->setTable("email_form");
    tabModelEmail->setEditStrategy(QSqlTableModel::OnManualSubmit);
    if(!(tabModelEmail->select()))
    {
        QMessageBox::critical(this,"错误","打开数据表错误,错误信息\n"
                              +tabModelEmail->lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    tabModelEmail->setHeaderData(tabModelEmail->fieldIndex("id"),Qt::Horizontal,"ID号");
    tabModelEmail->setHeaderData(tabModelEmail->fieldIndex("name"),Qt::Horizontal,"姓名");
    tabModelEmail->setHeaderData(tabModelEmail->fieldIndex("email"),Qt::Horizontal,"邮箱");
    tabModelEmail->setHeaderData(tabModelEmail->fieldIndex("identify"),Qt::Horizontal,"身份");


    theSelectionEmail=new QItemSelectionModel(tabModelEmail);

    ui->emailview->setModel(tabModelEmail);
    ui->emailview->setSelectionModel(theSelectionEmail);

    //学生信息表格
    tabModelstu_info=new QSqlTableModel(this,db);
    tabModelstu_info->setTable("stuinfo");
    tabModelstu_info->setEditStrategy(QSqlTableModel::OnManualSubmit);
    if(!(tabModelstu_info->select()))
    {
        QMessageBox::critical(this,"错误","打开数据表错误,错误信息\n"
                              +tabModelstu_info->lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    tabModelstu_info->setHeaderData(tabModelstu_info->fieldIndex("id"),Qt::Horizontal,"ID号");
    tabModelstu_info->setHeaderData(tabModelstu_info->fieldIndex("name"),Qt::Horizontal,"姓名");
    tabModelstu_info->setHeaderData(tabModelstu_info->fieldIndex("white_Bar"),Qt::Horizontal,"白条次数");
    tabModelstu_info->setHeaderData(tabModelstu_info->fieldIndex("Award"),Qt::Horizontal,"获奖情况");


    tabModelstu_info->setHeaderData(tabModelstu_info->fieldIndex("Competition"),Qt::Horizontal,"竞赛情况");
    tabModelstu_info->setHeaderData(tabModelstu_info->fieldIndex("academic_exchange"),Qt::Horizontal,"学术交流");
    tabModelstu_info->setHeaderData(tabModelstu_info->fieldIndex("Approved"),Qt::Horizontal,"审批通过");


    theSelectionstu_info=new QItemSelectionModel(tabModelstu_info);

    ui->stuinfoview->setModel(tabModelstu_info);
    ui->stuinfoview->setSelectionModel(theSelectionstu_info);
}


admin::~admin()
{
    delete ui;
}

void admin::on_addbutton_clicked()//添加信息
{
    switch (ui->tabWidget->currentIndex())
    {
    case 0:
            tabModelStudent->insertRow(tabModelStudent->rowCount(),QModelIndex());
            break;
    case 1:
            tabModelTeacher->insertRow(tabModelTeacher->rowCount(),QModelIndex());
            break;
    case 2:
            tabModelCourse->insertRow(tabModelCourse->rowCount(),QModelIndex());
            break;
    case 3:
            tabModelAdmin->insertRow(tabModelAdmin->rowCount(),QModelIndex());
            break;
    case 4:
            tabModelEmail->insertRow(tabModelEmail->rowCount(),QModelIndex());
            break;
    case 5:
            tabModelstu_info->insertRow(tabModelstu_info->rowCount(),QModelIndex());
            break;
    }
}

void admin::on_delbutton_clicked()
{
    switch (ui->tabWidget->currentIndex())
    {
    case 0://删除学生表中的数据
    {
        QItemSelectionModel *sModel=ui->studenview->selectionModel();
        //获取选中model里的索引
        QModelIndexList list=sModel->selectedRows();
        for(int i=0;i!=list.size();i++)
        {
            tabModelStudent->removeRow(list.at(i).row());
        }
            tabModelStudent->submitAll();
        break;
    }
    case 1://删除老师表中的数据
    {
        QItemSelectionModel *sModel=ui->teacherview->selectionModel();
        //获取选中model里的索引
        QModelIndexList list=sModel->selectedRows();
        for(int i=0;i!=list.size();i++)
        {
            tabModelTeacher->removeRow(list.at(i).row());
        }
            tabModelTeacher->submitAll();
        break;
    }
    case 2://删除课程表中的数据
    {
        QItemSelectionModel *sModel=ui->courseview->selectionModel();
        //获取选中model里的索引
        QModelIndexList list=sModel->selectedRows();
        for(int i=0;i!=list.size();i++)
        {
            tabModelCourse->removeRow(list.at(i).row());
        }
            tabModelCourse->submitAll();
        break;
    }
    case 3:
    {
        QItemSelectionModel *sModel=ui->chooseview->selectionModel();
        //获取选中model里的索引
        QModelIndexList list=sModel->selectedRows();
        for(int i=0;i!=list.size();i++)
        {
            tabModelAdmin->removeRow(list.at(i).row());
        }
            tabModelAdmin->submitAll();
        break;
    }
    case 4:
    {
        QItemSelectionModel *sModel=ui->emailview->selectionModel();
        //获取选中model里的索引
        QModelIndexList list=sModel->selectedRows();
        for(int i=0;i!=list.size();i++)
        {
            tabModelEmail->removeRow(list.at(i).row());
        }
            tabModelEmail->submitAll();
        break;
    }
    case 5:
    {
        QItemSelectionModel *sModel=ui->stuinfoview->selectionModel();
        //获取选中model里的索引
        QModelIndexList list=sModel->selectedRows();
        for(int i=0;i!=list.size();i++)
        {
            tabModelstu_info->removeRow(list.at(i).row());
        }
            tabModelstu_info->submitAll();
        break;
    }
    }
}

void admin::on_findbutton_clicked()
{
    if(ui->searchcombobox->currentText()=="精确查找")//如果searchcombobox选择为精确查找
    {
    if(ui->lineEdit->text().isEmpty()) {openTable();return;}
    QSqlQueryModel *model=new QSqlQueryModel;

    QSqlQuery query;
    QString find,sql0;
    find=ui->lineEdit->text();//获得文本框的信息

    if(ui->tabWidget->currentIndex()==0)//学生表格
    {
        if(ui->comboBox->currentText()=="姓名")
         {
        //按照姓名查找
            query.prepare("select id,name,sex,institute,age,password from student where name =:t_name");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
            query.bindValue(":t_name",find);
            if(!query.exec())
            {
                qDebug()<<"error";
            }

           model->setQuery(query);
            //qDebug()<<find;
           ui->studenview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"学号");
           model->setHeaderData(1,Qt::Horizontal,"姓名");
           model->setHeaderData(2,Qt::Horizontal,"性别");
           model->setHeaderData(3,Qt::Horizontal,"学院");
           model->setHeaderData(4,Qt::Horizontal,"年龄");
           model->setHeaderData(5,Qt::Horizontal,"密码");
        }

        if(ui->comboBox->currentText()=="学号")
         {
        //按照姓名查找
            query.prepare("select id,name,sex,institute,age,password from student where id =:t_id");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
            query.bindValue(":t_id",find);
            if(!query.exec())
            {
                qDebug()<<"error";
            }
           model->setQuery(query);
           ui->studenview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"学号");
           model->setHeaderData(1,Qt::Horizontal,"姓名");
           model->setHeaderData(2,Qt::Horizontal,"性别");
           model->setHeaderData(3,Qt::Horizontal,"学院");
           model->setHeaderData(4,Qt::Horizontal,"年龄");
           model->setHeaderData(5,Qt::Horizontal,"密码");
        }
    }

    else if(ui->tabWidget->currentIndex()==1)//老师表格
    {

        if(ui->comboBox->currentText()=="姓名")
         {
            qDebug()<<"正确的";

        //按照姓名查找
            query.prepare("select id,name,password from teacher where name =:t_name");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
            query.bindValue(":t_name",find);
            if(!query.exec())
            {
                qDebug()<<"error";
            }
           model->setQuery(query);
           ui->teacherview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"工号");
           model->setHeaderData(1,Qt::Horizontal,"姓名");
           model->setHeaderData(2,Qt::Horizontal,"密码");
        }

         if(ui->comboBox->currentText()=="工号")
         {
        //按照id查找
             query.prepare("select id,name,password from teacher where id =:t_id");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
             query.bindValue(":t_id",find);
             if(!query.exec())
             {
                 qDebug()<<"error";
             }
            model->setQuery(query);
           ui->teacherview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"工号");
           model->setHeaderData(1,Qt::Horizontal,"姓名");
           model->setHeaderData(2,Qt::Horizontal,"密码");
        }

    }

    else if(ui->tabWidget->currentIndex()==2)//课程表格
    {
        if(ui->comboBox->currentText()=="课程名")
         {
        //按照课程名精确查找
            query.prepare("select id,name,teacher,credit,institute from course where name =:t_name");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
            query.bindValue(":t_name",find);
            if(!query.exec())
            {
                qDebug()<<"error";
            }
           model->setQuery(query);
           ui->courseview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"课程号");
           model->setHeaderData(1,Qt::Horizontal,"课程名");
           model->setHeaderData(2,Qt::Horizontal,"教师");
           model->setHeaderData(3,Qt::Horizontal,"学分");
           model->setHeaderData(4,Qt::Horizontal,"学院");
        }

         if(ui->comboBox->currentText()=="课程号")
         {
         //按照课程号精确查找
            query.prepare("select id,name,teacher,credit,institute from course where id =:t_id");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
            query.bindValue(":t_id",find);
            if(!query.exec())
            {
                qDebug()<<"error";
            }
            model->setQuery(query);
            ui->courseview->setModel(model);
            model->setHeaderData(0,Qt::Horizontal,"课程号");
            model->setHeaderData(1,Qt::Horizontal,"课程名");
            model->setHeaderData(2,Qt::Horizontal,"教师");
            model->setHeaderData(3,Qt::Horizontal,"学分");
            model->setHeaderData(4,Qt::Horizontal,"学院");
        }

    }

    else if(ui->tabWidget->currentIndex()==3)//选课表格
    {
        if(ui->comboBox->currentText()=="课程号")
         {
         //按照课程号精确查找
               query.prepare("select cid,sid,grade,credit,absence,Attend_Status from scourse where cid =:t_id");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
               query.bindValue(":t_id",find);
               if(!query.exec())
               {
                   qDebug()<<"error";
               }
               model->setQuery(query);
           ui->chooseview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"课程号");
           model->setHeaderData(1,Qt::Horizontal,"学号");
           model->setHeaderData(2,Qt::Horizontal,"成绩");
           model->setHeaderData(3,Qt::Horizontal,"绩点");
           model->setHeaderData(4,Qt::Horizontal,"缺勤次数");
           model->setHeaderData(5,Qt::Horizontal,"签到情况");
         }

         if(ui->comboBox->currentText()=="学号")
         {
             query.prepare("select cid,sid,grade,credit,absence,Attend_Status from scourse where sid =:t_id");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
             query.bindValue(":t_id",find);
             if(!query.exec())
             {
                 qDebug()<<"error";
             }
             model->setQuery(query);
            ui->chooseview->setModel(model);
            model->setHeaderData(0,Qt::Horizontal,"课程号");
            model->setHeaderData(1,Qt::Horizontal,"学号");
            model->setHeaderData(2,Qt::Horizontal,"成绩");
            model->setHeaderData(3,Qt::Horizontal,"绩点");
            model->setHeaderData(4,Qt::Horizontal,"缺勤次数");
            model->setHeaderData(5,Qt::Horizontal,"签到情况");
         }
    }

    else if(ui->tabWidget->currentIndex()==4)//邮箱表格
    {
        if(ui->comboBox->currentText()=="姓名")
         {
            query.prepare("select id,name,email,identify from email_form where name =:t_name");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
            query.bindValue(":t_name",find);
            if(!query.exec())
            {
                qDebug()<<"error";
            }
            model->setQuery(query);
           ui->emailview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"id号");
           model->setHeaderData(1,Qt::Horizontal,"姓名");
           model->setHeaderData(2,Qt::Horizontal,"邮箱");
           model->setHeaderData(3,Qt::Horizontal,"身份");
        }

         if(ui->comboBox->currentText()=="ID号")
         {
             query.prepare("select id,name,email,identify from email_form where id =:t_id");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
             query.bindValue(":t_id",find);
             if(!query.exec())
             {
                 qDebug()<<"error";
             }
             model->setQuery(query);
             ui->emailview->setModel(model);
             model->setHeaderData(0,Qt::Horizontal,"id号");
             model->setHeaderData(1,Qt::Horizontal,"姓名");
             model->setHeaderData(2,Qt::Horizontal,"邮箱");
             model->setHeaderData(3,Qt::Horizontal,"身份");
        }
    }

    else if(ui->tabWidget->currentIndex()==5)//学生信息表格
    {
        if(ui->comboBox->currentText()=="姓名")
         {
            query.prepare("select id,name,white_Bar,Award,Competition,academic_exchange,Approved from stuinfo where name =:t_name");
            query.bindValue(":t_name",find);
            if(!query.exec())
            {
                qDebug()<<"error";
            }
            model->setQuery(query);
           ui->stuinfoview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"ID号");
           model->setHeaderData(1,Qt::Horizontal,"姓名");
           model->setHeaderData(2,Qt::Horizontal,"白条次数");
           model->setHeaderData(3,Qt::Horizontal,"获奖情况");
           model->setHeaderData(4,Qt::Horizontal,"竞赛情况");
           model->setHeaderData(5,Qt::Horizontal,"学术交流");
           model->setHeaderData(6,Qt::Horizontal,"审批通过");
         }

         if(ui->comboBox->currentText()=="ID号")
         {
        //按照id号查找
           query.prepare("select id,name,white_Bar,Award,Competition,academic_exchange,Approved from stuinfo where id =:t_id");
           query.bindValue(":t_id",find);
           if(!query.exec())
           {
               qDebug()<<"error";
           }
           model->setQuery(query);
           ui->stuinfoview->setModel(model);
           model->setHeaderData(0,Qt::Horizontal,"ID号");
           model->setHeaderData(1,Qt::Horizontal,"姓名");
           model->setHeaderData(2,Qt::Horizontal,"白条次数");
           model->setHeaderData(3,Qt::Horizontal,"获奖情况");
           model->setHeaderData(4,Qt::Horizontal,"竞赛情况");
           model->setHeaderData(5,Qt::Horizontal,"学术交流");
           model->setHeaderData(6,Qt::Horizontal,"审批通过");
         }
    }
   }
   else//如果searchcombobox选择为模糊查找
   {
        QSqlQueryModel *model=new QSqlQueryModel;

        QSqlQuery query;
        QString find,sql0;
        find=ui->lineEdit->text();//获得文本框的信息

        if(ui->tabWidget->currentIndex()==0)//学生表格
        {
            if(ui->comboBox->currentText()=="姓名")
             {
             //按照姓名模糊查找
               sql0="select id,name,sex,institute,age,password from student where name LIKE '%"+find+"%'";//根据关键词模糊查找


               model->setQuery(sql0);
                //qDebug()<<find;
               ui->studenview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"学号");
               model->setHeaderData(1,Qt::Horizontal,"姓名");
               model->setHeaderData(2,Qt::Horizontal,"性别");
               model->setHeaderData(3,Qt::Horizontal,"学院");
               model->setHeaderData(4,Qt::Horizontal,"年龄");
               model->setHeaderData(5,Qt::Horizontal,"密码");
            }

            if(ui->comboBox->currentText()=="学号")
             {
            //按照学号模糊查找
                  sql0="select id,name,sex,institute,age,password from student where id LIKE '%"+find+"%'";//根据关键词模糊查找


                  model->setQuery(sql0);
               ui->studenview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"学号");
               model->setHeaderData(1,Qt::Horizontal,"姓名");
               model->setHeaderData(2,Qt::Horizontal,"性别");
               model->setHeaderData(3,Qt::Horizontal,"学院");
               model->setHeaderData(4,Qt::Horizontal,"年龄");
               model->setHeaderData(5,Qt::Horizontal,"密码");
            }
        }

        else if(ui->tabWidget->currentIndex()==1)//老师表格
        {

            if(ui->comboBox->currentText()=="姓名")
             {
                //按照姓名模糊查找
                      sql0="select id,name,password from teacher where name LIKE '%"+find+"%'";//根据关键词模糊查找


                      model->setQuery(sql0);
                   ui->teacherview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"工号");
               model->setHeaderData(1,Qt::Horizontal,"姓名");
               model->setHeaderData(2,Qt::Horizontal,"密码");
            }

             if(ui->comboBox->currentText()=="工号")
             {
                 //按照工号模糊查找
                       sql0="select id,name,password from teacher where id LIKE '%"+find+"%'";//根据关键词模糊查找


                       model->setQuery(sql0);
                    ui->teacherview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"工号");
               model->setHeaderData(1,Qt::Horizontal,"姓名");
               model->setHeaderData(2,Qt::Horizontal,"密码");
            }

        }

        else if(ui->tabWidget->currentIndex()==2)//课程表格
        {
            if(ui->comboBox->currentText()=="课程名")
             {
            //按照姓名查找
                 sql0="select id,name,teacher,credit,institute from course where name LIKE '%"+find+"%'";
                model->setQuery(sql0);
                //qDebug()<<find;
               ui->courseview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"课程号");
               model->setHeaderData(1,Qt::Horizontal,"课程名");
               model->setHeaderData(2,Qt::Horizontal,"教师");
               model->setHeaderData(3,Qt::Horizontal,"学分");
               model->setHeaderData(4,Qt::Horizontal,"学院");
            }

             if(ui->comboBox->currentText()=="课程号")
             {
            //按照id号查找
                 sql0="select id,name,teacher,credit,institute from course where id LIKE '%"+find+"%'";
                 model->setQuery(sql0);
                 //qDebug()<<find;
                ui->courseview->setModel(model);
                model->setHeaderData(0,Qt::Horizontal,"课程号");
                model->setHeaderData(1,Qt::Horizontal,"课程名");
                model->setHeaderData(2,Qt::Horizontal,"教师");
                model->setHeaderData(3,Qt::Horizontal,"学分");
                model->setHeaderData(4,Qt::Horizontal,"学院");
            }

        }

        else if(ui->tabWidget->currentIndex()==3)//选课表格
        {
            if(ui->comboBox->currentText()=="课程号")
             {
            //按照姓名查找
                sql0="select cid,sid,grade,credit,absence,Attend_Status from scourse where cid LIKE '%"+find+"%'";
                model->setQuery(sql0);
                //qDebug()<<find;
               ui->chooseview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"课程号");
               model->setHeaderData(1,Qt::Horizontal,"学号");
               model->setHeaderData(2,Qt::Horizontal,"成绩");
               model->setHeaderData(3,Qt::Horizontal,"绩点");
               model->setHeaderData(4,Qt::Horizontal,"缺勤次数");
               model->setHeaderData(5,Qt::Horizontal,"签到情况");
             }

             if(ui->comboBox->currentText()=="学号")
             {
            //按照id号查找
                            sql0="select cid,sid,grade,credit,absence,Attend_Status from scourse where sid LIKE '%"+find+"%'";
                model->setQuery(sql0);
                //qDebug()<<find;
                ui->chooseview->setModel(model);
                model->setHeaderData(0,Qt::Horizontal,"课程号");
                model->setHeaderData(1,Qt::Horizontal,"学号");
                model->setHeaderData(2,Qt::Horizontal,"成绩");
                model->setHeaderData(3,Qt::Horizontal,"绩点");
                model->setHeaderData(4,Qt::Horizontal,"缺勤次数");
                model->setHeaderData(5,Qt::Horizontal,"签到情况");
             }
        }

        else if(ui->tabWidget->currentIndex()==4)//邮箱表格
        {
            if(ui->comboBox->currentText()=="姓名")
             {
            //按照姓名查找
                sql0="select id,name,email,identify from email_form where name LIKE '%"+find+"%'";
                model->setQuery(sql0);
                //qDebug()<<find;
               ui->emailview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"id号");
               model->setHeaderData(1,Qt::Horizontal,"姓名");
               model->setHeaderData(2,Qt::Horizontal,"邮箱");
               model->setHeaderData(3,Qt::Horizontal,"身份");
            }

             if(ui->comboBox->currentText()=="ID号")
             {
            //按照id号查找
                 sql0="select id,name,email,identify from email_form where id LIKE '%"+find+"%'";
                 model->setQuery(sql0);
                 //qDebug()<<find;
                 ui->emailview->setModel(model);
                 model->setHeaderData(0,Qt::Horizontal,"id号");
                 model->setHeaderData(1,Qt::Horizontal,"姓名");
                 model->setHeaderData(2,Qt::Horizontal,"邮箱");
                 model->setHeaderData(3,Qt::Horizontal,"身份");
            }
        }

        else if(ui->tabWidget->currentIndex()==5)//学生信息表格
        {
            if(ui->comboBox->currentText()=="姓名")
             {
            //按照姓名查找
                sql0="select id,name,white_Bar,Award,Competition,academic_exchange,Approved from stuinfo where name LIKE '%"+find+"%'";
                model->setQuery(sql0);
                //qDebug()<<find;
               ui->stuinfoview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"ID号");
               model->setHeaderData(1,Qt::Horizontal,"姓名");
               model->setHeaderData(2,Qt::Horizontal,"白条次数");
               model->setHeaderData(3,Qt::Horizontal,"获奖情况");
               model->setHeaderData(4,Qt::Horizontal,"竞赛情况");
               model->setHeaderData(5,Qt::Horizontal,"学术交流");
               model->setHeaderData(6,Qt::Horizontal,"审批通过");
             }

             if(ui->comboBox->currentText()=="ID号")
             {
            //按照id号查找
                sql0="select id,name,white_Bar,Award,Competition,academic_exchange,Approved from stuinfo where id LIKE '%"+find+"%'";
                model->setQuery(sql0);
                //qDebug()<<find;
               ui->stuinfoview->setModel(model);
               model->setHeaderData(0,Qt::Horizontal,"ID号");
               model->setHeaderData(1,Qt::Horizontal,"姓名");
               model->setHeaderData(2,Qt::Horizontal,"白条次数");
               model->setHeaderData(3,Qt::Horizontal,"获奖情况");
               model->setHeaderData(4,Qt::Horizontal,"竞赛情况");
               model->setHeaderData(5,Qt::Horizontal,"学术交流");
               model->setHeaderData(6,Qt::Horizontal,"审批通过");
             }
        }
   }
}


void admin::getCurrChanged(int value)//tabWidget切换时信号槽函数
{
      if(value == 0)
      {
          ui->comboBox->clear();
          ui->comboBox->addItem("学号");
          ui->comboBox->addItem("姓名");
      }
      else if(value == 1)
      {
          ui->comboBox->clear();
          ui->comboBox->addItem("工号");
          ui->comboBox->addItem("姓名");
      }
      else if(value == 2)
      {
          ui->comboBox->clear();
          ui->comboBox->addItem("课程号");
          ui->comboBox->addItem("课程名");
      }
      else if(value == 3)
      {
          ui->comboBox->clear();
          ui->comboBox->addItem("课程号");
          ui->comboBox->addItem("学号");
          ui->comboBox->addItem("绩点");
      }
      else if(value == 4)
      {
          ui->comboBox->clear();
          ui->comboBox->addItem("ID号");
          ui->comboBox->addItem("姓名");
      }
      else if(value == 5)
      {
          ui->comboBox->clear();
          ui->comboBox->addItem("ID号");
          ui->comboBox->addItem("姓名");
          ui->comboBox->addItem("白条次数");
      }
}

void admin::on_topbutton_clicked()//升序排列
{
    if(ui->comboBox->currentText()=="绩点")
    {
         tabModelAdmin->submitAll();
         tabModelAdmin->sort(3,Qt::AscendingOrder);//选课表表格第四列按照升序排序
         tabModelAdmin->submitAll();
    }
    else if(ui->comboBox->currentText()=="白条次数")
    {
         tabModelstu_info->submitAll();
         tabModelstu_info->sort(2,Qt::AscendingOrder);//学术信息表格第三列按照升序排序
         tabModelstu_info->submitAll();
    }
    else
    {
         tabModelStudent->submitAll();
         tabModelTeacher->submitAll();
         tabModelCourse->submitAll();
         tabModelEmail->submitAll();
         tabModelStudent->sort(0,Qt::AscendingOrder);//学生表格第一列按照升序排序
         tabModelTeacher->sort(0,Qt::AscendingOrder);//老师表格第一列按照升序排序
         tabModelCourse->sort(0,Qt::AscendingOrder);//课程表格第一列按照升序排序
         tabModelEmail->sort(0,Qt::AscendingOrder);//邮箱表格第一列按照升序排序
         tabModelAdmin->sort(0,Qt::AscendingOrder);//选课表表格第一列按照升序排序
         tabModelStudent->submitAll();
         tabModelTeacher->submitAll();
         tabModelCourse->submitAll();
         tabModelEmail->submitAll();
    }
}

void admin::on_lowbutton_clicked()//降序排列
{
    if(ui->comboBox->currentText()=="绩点")
    {
         tabModelAdmin->submitAll();
         tabModelAdmin->sort(3,Qt::DescendingOrder);//选课表表格第四列按照降序排序
         tabModelAdmin->submitAll();
    }
    else if(ui->comboBox->currentText()=="白条次数")
    {
         tabModelstu_info->submitAll();
         tabModelstu_info->sort(2,Qt::DescendingOrder);//学术信息表格第二列按照降序排序
         tabModelstu_info->submitAll();
    }
    else
    {
         tabModelStudent->submitAll();
         tabModelTeacher->submitAll();
         tabModelCourse->submitAll();
         tabModelEmail->submitAll();
         tabModelStudent->sort(0,Qt::DescendingOrder);//学生表格第一列按照降序排序
         tabModelTeacher->sort(0,Qt::DescendingOrder);//老师表格第一列按照降序排序
         tabModelCourse->sort(0,Qt::DescendingOrder);//课程表格第一列按照降序排序
         tabModelEmail->sort(0,Qt::DescendingOrder);//邮箱表格第一列按照升序排序
         tabModelAdmin->sort(0,Qt::DescendingOrder);//选课表格第一列按照升序排序
         tabModelStudent->submitAll();
         tabModelTeacher->submitAll();
         tabModelCourse->submitAll();
         tabModelEmail->submitAll();
    }
}

void admin::on_emailbutton_clicked()//邮件
{
    send_email *Send_email=new send_email;
    Send_email->show();
    openTable();
}

void admin::on_savebutton_clicked()//保存
{
    tabModelStudent->submitAll();
    tabModelTeacher->submitAll();
    tabModelCourse->submitAll();
    tabModelEmail->submitAll();
    tabModelAdmin->submitAll();
    tabModelstu_info->submitAll();
}
