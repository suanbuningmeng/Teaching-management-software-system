#ifndef COMPETITION_H
#define COMPETITION_H

#include <QSqlQuery>
#include <QSqlRecord>
#include <QMessageBox>
#include <QSqlTableModel>
#include <QDateTime>
#include <QDebug>
#include <QWidget>
#include <QSqlDatabase>
#include <QTcpSocket>
#include <QTcpServer>
#include <QSqlError>
#include "db.h"

namespace Ui {
class competition;
}

class competition : public QWidget
{
    Q_OBJECT

private slots:
    void Init();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

public:
    explicit competition(QWidget *parent = nullptr);
    ~competition();

private:
    Ui::competition *ui;
    QSqlDatabase db;
    QString _name;
};

#endif // COMPETITION_H
