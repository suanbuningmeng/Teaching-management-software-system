#include "db.h"

QString DB_HOSTNAME="192.168.43.220"; //ip地址
QString DB_USERNAME="root";   //mysql用户名
QString DB_PASSWORD="1234";   //mysql数据库的密码
QString DB_NAME="data"; //mysql数据库

QString LoginId="";

