#ifndef SEND_EMAIL_H
#define SEND_EMAIL_H

#include <QWidget>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQuery>
#include <QTimer>
#include <QThread>
#include "EMail.h"

namespace Ui {
class send_email;
}

class send_email : public QWidget
{
    Q_OBJECT

private slots:

public:
    explicit send_email(QWidget *parent = nullptr);
    ~send_email();
    void Init();

private slots:
   void on_pushButton_2_clicked();
   void on_send_student_clicked();
   void on_send_teacher_clicked();

private:
    Ui::send_email *ui;
    QSqlDatabase db;
};

#endif // SEND_EMAIL_H
