#ifndef SEND_EMAIL_TS_H
#define SEND_EMAIL_TS_H

#include <QWidget>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQuery>
#include <QTimer>
#include <QThread>
#include "EMail.h"

namespace Ui {
class send_email_ts;
}

class send_email_ts : public QWidget
{
    Q_OBJECT

public:
    explicit send_email_ts(QWidget *parent = nullptr);
    ~send_email_ts();
    void Init();

private slots:
   void on_pushButton_2_clicked();

private:
    Ui::send_email_ts *ui;
    QSqlDatabase db;
};

#endif // SEND_EMAIL_TS_H
