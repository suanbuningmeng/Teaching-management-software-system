#ifndef STUDENTACCOUNT_H
#define STUDENTACCOUNT_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QSqlQuery>
#include "db.h"
#include <QtSql>
#include <QMessageBox>
#include <QDataWidgetMapper>

namespace Ui {
class studentaccount;
}

class studentaccount : public QWidget
{
    Q_OBJECT

private slots:
    void Init();

    void on_pushButton_clicked();

public:
    explicit studentaccount(QWidget *parent = nullptr);
    ~studentaccount();

private:
    Ui::studentaccount *ui;
    QSqlDatabase db;
};

#endif // STUDENTACCOUNT_H
