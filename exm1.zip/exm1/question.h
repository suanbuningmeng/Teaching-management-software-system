#ifndef QUESTION_H
#define QUESTION_H

#include <QWidget>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QMenu>

#include <QtSql>
#include <QMessageBox>
#include "db.h"//连接数据库来获取身份
//每个用户登录既是客户端又是服务器端
//采用udp进行通信聊天
//客户端:首先当客户端登录时，获取本机的用户名，计算机名和ip地址，并广播给局域网的服务器更新用户列表。然后当客户端需要发送信息时，则在聊天输入栏中输入信息并按发送键发送聊天内容，当然于此同时也广播本地系统的各种信息。
//服务器端:建立一个UDP Socket并绑定在固定端口后，用信号与槽的方式进行监听是否有数据来临。如果用，接收其数据并分析数据的消息类型，如果消息是新用户登录则更新用户列表并在聊天显示窗口中添加新用户上线通知；同理，如果是用户下线，则在用户列表中删除该用户且在聊天显示窗口中显示下线通知；如果是聊天消息，则接收该消息并且在窗口中显示。

namespace Ui {
class question;
}

class QUdpSocket;
class TcpServer;
class QTextCharFormat;

//枚举变量分别表示消息类型、新用户加入、用户退出、文件名、拒绝接受文件
enum MessageType {Message,NewParticipant,ParticipantLeft};

struct User{
    QString name;
    QString id;
    QString address;
};

class question : public QWidget
{
    Q_OBJECT

public:
    explicit question(QWidget *parent = 0,User u = {"","",""});
    ~question();
    //用于从登陆端接收用户信息
    void setUser(User u);

protected:
    //新成员加入
    void newParticipant(QString userName,
                        QString ID,QString ipAddress);
    //成员离开
    void participantLeft(QString username,
                         QString ID,QString time);
    //关闭事件
    void closeEvent(QCloseEvent *event);
    //事件过滤器，按下回车发送信息
    bool eventFilter(QObject *obj, QEvent *event);

    //广播用户登录信息
    void sendMessage(MessageType type,QString serverAddress = "");

    //获取IP地址
    QString getIP();
    //获取用户名
    QString getUserName();

    //获取用户名
    QString get_ID();

    //获取消息
    QString getMessage();


private slots:
    //接收广播消息——槽
    void processPendingDatagrams();
    //发送按钮--槽
    void on_sendButton_clicked();
    //设置字体
    void on_fontComboBox_currentFontChanged(const QFont &f);
    //更改字体大小
    void on_SizeComboBox_currentIndexChanged(const QString &arg1);
    //设置字体时可切换到相应状态
    void currentFormatChanged(const QTextCharFormat &format);
    //清空聊天记录--槽
    void on_clearToolBtn_clicked();
    //字体颜色
    void on_colorToolBtn_clicked();


private:
    Ui::question *ui;
    QUdpSocket *udpSocket;//udp通信，采用udp通信进行聊天
    qint16 port;  //端口
    QString fileName;
    TcpServer *server;//服务端
    QColor color;//文本颜色
    User user;
    QString identify;//用户身份
    QSqlDatabase db;
};

#endif // QUESTION_H
