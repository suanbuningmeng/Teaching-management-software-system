#ifndef CORRECT_HOMEWORK_H
#define CORRECT_HOMEWORK_H
#include <vector>
#include <map>
using namespace std;

#include <QSqlQuery>
#include <QSqlRecord>
#include <QMessageBox>
#include <QSqlTableModel>
#include <QDateTime>
#include <QDebug>
#include <QWidget>
#include <QSqlDatabase>
#include <QTcpSocket>
#include <QTcpServer>
#include <QSqlError>
#include "db.h"

namespace Ui {
class correct_homework;
}

class correct_homework : public QWidget
{
    Q_OBJECT

public:
    explicit correct_homework(QWidget *parent = nullptr);
    ~correct_homework();

private slots:
    void on_paper_select_clicked();
    void Init();

    void on_Score_put_clicked();

    void on_nextbutton_clicked();
    void Item_Change();

    void on_surebutton_clicked();

    void on_backbutton_clicked();

private:
    Ui::correct_homework *ui;
    QSqlDatabase db;

    QString choosepaperid,choosestudent;//记录抽取试卷信息
    vector<int>     number;        //记录主观题试卷题目序号
    vector<QString> questions; //记录主观题编号
    vector<QString> values;    //记录分值
    vector<QString> studentsofexam;//记录发布考试涉及的学生
    vector<QString> students;    //记录分值

    map<QString,QTcpSocket*> sockets;//记录tcp连接和学生对应关系
    int id;//记录当前展示的是第几题
    QTcpServer *server;
    int a;
};

#endif // CORRECT_HOMEWORK_H
