#ifndef GRADE_H
#define GRADE_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtSql>
#include "db.h"
#include <QMessageBox>

namespace Ui {
class grade;
}

class grade : public QWidget
{
    Q_OBJECT

public:

    explicit grade(QWidget *parent = nullptr);
    ~grade();
    void Init();

private:
    Ui::grade *ui;
    QSqlDatabase db;
    QString _name;
};

#endif // GRADE_H
