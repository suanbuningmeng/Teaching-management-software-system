#include "teacher.h"
#include "ui_teacher.h"
#include <QtDebug>
#include <QTimer>
#include <QRegExpValidator>
#include <QMessageBox>


teacher::teacher(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::teacher)
{
    ui->setupUi(this);
    setWindowTitle("学生成绩管理");

    Init();//初始化，连接数据库

    connect(ui->lineEdit,SIGNAL(textChanged(QString)),this,SLOT(on_findbutton_clicked()));//当lineEdit有字符变化时发出信号
    connect(ui->comboBox,SIGNAL(currentIndexChanged(QString)),this,SLOT(on_selectbutton_clicked()));//当lineEdit有字符变化时发出信号

    ui->comboBox_2->addItem("姓名");
    ui->comboBox_2->addItem("学号");
    ui->comboBox_2->addItem("课程号");
}

teacher::~teacher()
{
    delete ui;
}

void teacher::Init()//初始化
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
    QSqlQuery query;
    query.prepare("SELECT id,name FROM teacher WHERE id=:ID");//在teacher表中寻找老师的信息
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();
    t_name =query.value("name").toString();
    //qDebug()<<"or here";
    ui->namelabel->clear();
    ui->namelabel->setText("工号："+query.value("id").toString()+"  欢迎您！");


    query.clear();

    query.prepare("SELECT sc.cid,c.name,sc.sid,s.name,sc.grade,sc.credit,sc.absence from scourse sc,student s,course c"
                  " where sc.sid=s.id and c.id=sc.cid and c.teacher=:name");  //先根据老师的姓名在老师表中找到这个老师所教课程的课程号，再根据这个课程号，在课程信息表和学生课程信息表中找到这个老师所教这个课程的所有学生信息
    query.bindValue(":name",t_name);

    if(!query.exec())
    {
        qDebug()<<"初始化就错了";
    }
    query.first();//直接指向结果集的第一条

   // qDebug()<<query.value("AVG(grade)").toString()<<query.value("avg_grade").toString();
    QSqlQueryModel *c_model = new QSqlQueryModel;
    c_model->setQuery(query);
    c_model->setHeaderData(0,Qt::Horizontal,"课程号");
    c_model->setHeaderData(1,Qt::Horizontal,"课程名");
    c_model->setHeaderData(2,Qt::Horizontal,"学号");
    c_model->setHeaderData(3,Qt::Horizontal,"姓名");
    c_model->setHeaderData(4,Qt::Horizontal,"成绩");
    c_model->setHeaderData(5,Qt::Horizontal,"绩点");
    c_model->setHeaderData(6,Qt::Horizontal,"缺勤次数");
    ui->tableView->setModel(c_model);

//把这个老师所叫教的科目放到combox中
    ui->comboBox->clear();
    QVector<QString> subjects;//科目列表
    QString sql;
    ui->comboBox->addItem("所有科目");   //先加一个所有学生
//    sql = QString("select * from course where teacher:name");

      sql = QString("select * from course where teacher = '%1';").arg(t_name);
    if(query.exec(sql))
    {
        while(query.next())
        {
            subjects.push_back(query.value(1).toString());
            //qDebug()<<query.value(1).toString();
        }
    }

    int n = subjects.size();
    for(int i = 0; i < n ; ++i)
    {
        ui->comboBox->addItem(subjects[i]);
    }
}

void teacher::on_findbutton_clicked()
{
    QSqlQuery query;
    QString find;
    find=ui->lineEdit->text();//获得文本框的信息


/*********按姓名查询************/
    if(ui->comboBox_2->currentText()== "姓名")
    {
    query.prepare("SELECT e.cid,c.name,e.sid,s.name,e.grade,e.credit,e.absence from scourse e,student s,course c"
                  " where e.sid=s.id and c.id=e.cid and c.teacher=:name and s.name LIKE '%"+find+"%' ");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
    query.bindValue(":name",t_name);
    }
/*********按姓名查询************/


/*********按学生id查询************/
    else if(ui->comboBox_2->currentText()== "学号")
    {
        query.prepare("SELECT e.cid,c.name,e.sid,s.name,e.grade,e.credit,e.absence from scourse e,student s,course c"
                      " where e.sid=s.id and c.id=e.cid and c.teacher=:name and s.id LIKE '%"+find+"%' ");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
        query.bindValue(":name",t_name);
    }
/*********按学生id查询************/


/*********教师开课查询************/
        else if(ui->comboBox_2->currentText()== "课程号")
        {
            query.prepare("SELECT e.cid,c.name,e.sid,s.name,e.grade,e.credit,e.absence from scourse e,student s,course c"
                          " where e.sid=s.id and c.id=e.cid and c.teacher=:name and e.cid LIKE '%"+find+"%' ");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生
            query.bindValue(":name",t_name);
        }
/*********教师开课查询************/
       else
        {
        QMessageBox::information(this,"警告","未知错误");
        return;
        }
    if(!query.exec())
    {
        qDebug()<<"error";
    }
    query.first();//直接指向结果集的第一条
    QSqlQueryModel *c_model = new QSqlQueryModel;
    c_model->setQuery(query);
    c_model->setHeaderData(0,Qt::Horizontal,"课程号");
    c_model->setHeaderData(1,Qt::Horizontal,"课程名");
    c_model->setHeaderData(2,Qt::Horizontal,"学号");
    c_model->setHeaderData(3,Qt::Horizontal,"姓名");
    c_model->setHeaderData(4,Qt::Horizontal,"成绩");
    c_model->setHeaderData(5,Qt::Horizontal,"绩点");
    c_model->setHeaderData(6,Qt::Horizontal,"缺勤次数");
    ui->tableView->setModel(c_model);
}

void teacher::on_selectbutton_clicked()
{
    if(ui->comboBox->currentText() == "所有科目")
    {
        QSqlQuery query;


        query.prepare("SELECT sc.cid,c.name,sc.sid,s.name,sc.grade,sc.credit,sc.absence from scourse sc,student s,course c"
                      " where sc.sid=s.id and c.id=sc.cid and c.teacher=:name");  //先根据老师的姓名在老师表中找到这个老师所教课程的课程号，再根据这个课程号，在课程信息表和学生课程信息表中找到这个老师所教这个课程的所有学生信息
        query.bindValue(":name",t_name);

        if(!query.exec())
        {
            qDebug()<<"初始化就错了";
        }
        query.first();//直接指向结果集的第一条

       // qDebug()<<query.value("AVG(grade)").toString()<<query.value("avg_grade").toString();
        QSqlQueryModel *c_model = new QSqlQueryModel;
        c_model->setQuery(query);
        c_model->setHeaderData(0,Qt::Horizontal,"课程号");
        c_model->setHeaderData(1,Qt::Horizontal,"课程名");
        c_model->setHeaderData(2,Qt::Horizontal,"学号");
        c_model->setHeaderData(3,Qt::Horizontal,"姓名");
        c_model->setHeaderData(4,Qt::Horizontal,"成绩");
        c_model->setHeaderData(5,Qt::Horizontal,"绩点");
        c_model->setHeaderData(6,Qt::Horizontal,"缺勤次数");
        ui->tableView->setModel(c_model);
    }
    else
    {
        QString subject;
        QSqlQuery query;
        subject=ui->comboBox->currentText();//获取科目

        query.prepare("SELECT sc.cid,c.name,sc.sid,s.name,sc.grade,sc.credit,sc.absence from scourse sc,student s,course c"
                  " where sc.sid=s.id and c.id=sc.cid and c.teacher=:name and c.name=:cor_name");  //先根据老师的姓名在老师表中找到这个老师所教课程的课程号，再根据这个课程号，在课程信息表和学生课程信息表中找到这个老师所教这个课程的所有学生信息

        query.bindValue(":name",t_name);
        query.bindValue(":cor_name",subject);
        if(!query.exec())
        {
            qDebug()<<"Error";
        }
        query.first();//直接指向结果集的第一条
        QSqlQueryModel *c_model = new QSqlQueryModel;

        c_model->setQuery(query);
        c_model->setHeaderData(0,Qt::Horizontal,"课程号");
        c_model->setHeaderData(1,Qt::Horizontal,"课程名");
        c_model->setHeaderData(2,Qt::Horizontal,"学号");
        c_model->setHeaderData(3,Qt::Horizontal,"姓名");
        c_model->setHeaderData(4,Qt::Horizontal,"成绩");
        c_model->setHeaderData(5,Qt::Horizontal,"绩点");
        c_model->setHeaderData(6,Qt::Horizontal,"缺勤次数");
        ui->tableView->setModel(c_model);
     }
}


void teacher::on_modifybutton_clicked()
{
    modify_sco *Modify_sco=new modify_sco;
    Modify_sco->show();
    Init();
}

void teacher::on_refleshbutton_clicked()
{
    Init();
}

