#ifndef TEACHER_HOMEWORD_H
#define TEACHER_HOMEWORD_H

#include <QWidget>

namespace Ui {
class teacher_homework;
}

class teacher_homework : public QWidget
{
    Q_OBJECT

public:
    explicit teacher_homework(QWidget *parent = nullptr);
    ~teacher_homework();

private:
    Ui::teacher_homework *ui;
};

#endif // TEACHER_HOMEWORD_H
