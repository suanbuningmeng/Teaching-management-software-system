#include "question.h"
#include "ui_question.h"
#include <QFileDialog>
#include <QUdpSocket>
#include <QHostInfo>
#include <QMessageBox>
#include <QScrollBar>
#include <QDateTime>
#include <QNetworkInterface>
#include <QProcess>
#include <QColorDialog>
#include <QTextCharFormat>
#include <QKeyEvent>

question::question(QWidget *parent,User u) :
    QWidget(parent),
    ui(new Ui::question)
{
    ui->setupUi(this);
    setUser(u);
    setWindowTitle("答疑室");

    udpSocket = new QUdpSocket(this); //创建一个QUdpSocket对象
    port = (qint16)45454;   //设置端口号
    udpSocket->bind(port,QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);    //连接本机的port端口，采用ShareAddress模式(即允许其它的服务连接到相同的地址和端口，特别是
    //用在多客户端监听同一个服务器端口等时特别有效)，和ReuseAddressHint模式(重新连接服务器)
    connect(udpSocket,SIGNAL(readyRead()),this,SLOT(processPendingDatagrams()));  //信号槽函数，每当有新的数据来临时就触发processPendingDatagrams()函数
    sendMessage(NewParticipant);//打开软件时就向外发射本地信息，让其他在线用户得到通知

    //设置消息过滤器,允许拦截和处理窗口部件接收到的事件，包括键盘事件和鼠标事件等。
    ui->messageTextEdit->installEventFilter(this);
}

//根据消息类型发送
//sendMessage即把本机的主机名，用户名+（消息内容后ip地址）广播出去
void question::sendMessage(MessageType type, QString serverAddress)
{
    QByteArray data;//创建一个 QByteArray 对象 data，用于存储数据
    QDataStream out(&data,QIODevice::WriteOnly);//使用 QDataStream 对象 out 来操作 data，并设置其写入模式(QIODevice::WriteOnly)
    QString ID= get_ID();
    QString address = getIP();
    out << type << getUserName() << ID;

    //判断发送消息的类型
    switch(type)
    {
    case Message:
        //发送的是消息
        if(ui->messageTextEdit->toPlainText() == "")//输入框不得为空
        {
            QMessageBox::warning(0,tr("警告"),
                                 tr("发送内容不能为空"),QMessageBox::Ok);
            return;
        }
        out << address << getMessage();//将address和getMessage()写入到输出流out中。这里的address表示接收方的地址，getMessage()获取了要发送的消息。
        ui->messageBrowser->verticalScrollBar()
                ->setValue(ui->messageBrowser->verticalScrollBar()->maximum());//设置消息浏览器messageBrowser的垂直滚动条到最大值
        break;

    case NewParticipant:
        //广播新用户加入的消息
        //为什么此时只是输出地址这一项呢？因为此时不需要传递聊天内容
        out << address;
        break;

    case ParticipantLeft:
        //广播用户离开的消息
        break;

    }
    //一个udpSocket已经与一个端口bind在一起了，这里的data是out流中的data，最多可以传送8192个字节，但是建议不要超过
    //512个字节，因为这样虽然可以传送成功，但是这些数据需要在ip层分组，QHostAddress::Broadcast是指发送数据的目的地址
    //这里为本机所在地址的广播组内所有机器，即局域网广播发送
    //进行udp广播，writeDatagram(): QUdpSocket的函数，用于向给定的主机地址和端口发送数据报文
    udpSocket->writeDatagram(data,data.length(),QHostAddress::Broadcast,port);//使用UDP套接字将data中的数据报文通过广播方式发送给局域网内的所有主机，目标主机的端口号为port
}

//成员加入处理函数
void question::newParticipant(QString userName, QString ID, QString ipAddress)
{
    //判断用户是否已经加入
    bool isEmpty = ui->userTableWidget
            ->findItems(ID,Qt::MatchExactly).isEmpty();

    //如果用户未加入，则会向界面右侧的用户列表添加新用户的信息
    if(isEmpty)
    {
        QTableWidgetItem *user = new QTableWidgetItem(userName);   //姓名
        QTableWidgetItem *id = new QTableWidgetItem(ID);           //学号
        QTableWidgetItem *ip = new QTableWidgetItem(ipAddress);    //ip地址
        db=QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName(DB_HOSTNAME);
        db.setDatabaseName(DB_NAME);
        db.setUserName(DB_USERNAME);
        db.setPassword(DB_PASSWORD);
        db.setPort(3306);
        if(!db.open())
        {
            QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                                +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

            return;
        }
        QSqlQuery query;
        query.prepare("SELECT identify FROM email_form WHERE id=:ID");
        query.bindValue(":ID",ID);
        query.exec();
        query.first();
        identify=query.value("identify").toString(); //根据学号获取身份
        QTableWidgetItem *identifyItem = new QTableWidgetItem(identify);    //身份

        ui->userTableWidget->insertRow(0);
        ui->userTableWidget->setItem(0,0,identifyItem);
        ui->userTableWidget->setItem(0,1,user);
        ui->userTableWidget->setItem(0,2,id);

        ui->messageBrowser->setTextColor(Qt::blue);//设置消息框文本颜色为蓝色
        ui->messageBrowser->setCurrentFont(QFont("Times New Roman",10));//设置字体和字号
        ui->messageBrowser->append(tr("%1 在线").arg(userName));
        ui->userNumLabel->setText(tr("在线人数： %1")
                                  .arg(ui->userTableWidget->rowCount()));//更新在线人数
        //发送新用户登录消息
        sendMessage(NewParticipant);
    }
}

//成员离开处理函数
void question::participantLeft(QString username, QString ID, QString time)
{
    int rowNum = ui->userTableWidget->findItems(ID,
                                                Qt::MatchExactly).first()->row();//找到表格中学号列 (ID) 匹配给定 ID 的第一个匹配项，并调用 row() 函数获取该项所在的行数
    ui->userTableWidget->removeRow(rowNum);//删除该行信息
    ui->messageBrowser->setTextColor(Qt::green);//设置文本颜色为黄色
    ui->messageBrowser->setCurrentFont(QFont("Times New Roman",10));//设置字体与字号
    ui->messageBrowser->append(tr("%1 于 %2 离开！").arg(username).arg(time));//显示离开信息
    ui->userNumLabel->setText(tr("在线人数： %1")
                              .arg(ui->userTableWidget->rowCount()));//更新在线人数
}

// 获取ip地址，获取本机ip地址(其协议为ipv4的ip地址)
//QList<QHostAddress> list = QNetworkInterface::allAddresses();//此处的所有地址是指ipv4和ipv6的地址
//foreach (variable, container),此处为按照容器list中条目的顺序进行迭代
QString question::getIP()
{
#if 0
    QList<QHostAddress>list = QNetworkInterface::allAddresses();
    foreach(QHostAddress address,list) {
        if(address.protocol() == QAbstractSocket::IPv4Protocol)
            return address.toString();
    }
    return 0;
#endif
    return user.address;
}

//获取用户名
QString question::getUserName()
{
#if 0
    QStringList envVariables;
    envVariables << "USERNAME.*" << "USER.*" << "USERDOMAIN.*"
                 << "HOSTNAME.*" << "DOMAINNAME.*";
    QStringList environment = QProcess::systemEnvironment();
    foreach(QString string,envVariables)
    {
        int index = environment.indexOf(QRegExp(string));
        if(index != -1) {
            QStringList stringList = environment.at(index).split('=');
            if(stringList.size() == 2)
            {
                qDebug() << stringList.at(1);
                return stringList.at(1);
                break;
            }
        }
    }
    return "unKnow";
#endif
    return user.name;
}

QString question::get_ID()
{
     return user.id;
}

//获取用户输入的消息并设置
QString question::getMessage()
{
    QString msg = ui->messageTextEdit->toHtml();//将messageTextEdit文本编辑器中的内容以HTML格式获取，并存储在msg字符串变量中
    ui->messageTextEdit->clear();   //将文本编辑器内容清空
    ui->messageTextEdit->setFocus(); //重新将焦点设置到messageTextEdit文本编辑器上，以便用户可以直接进行下一次输入
    return msg;//将获取到的HTML格式文本作为函数的返回值返回
}

void question::setUser(User u)
{
    user.name = u.name;
    user.address = u.address;
    user.id = u.id;
}
//关闭事件：在关闭程序时发送用户离开的广播，让其他端点在其用户列表中删除用户
void question::closeEvent(QCloseEvent *event)
{
    sendMessage(ParticipantLeft);
    QWidget::closeEvent(event);
}

//快捷键ctrl+enter发送消息
bool question::eventFilter(QObject *obj, QEvent *event)
{
#if 1
    if(obj == ui->messageTextEdit){

        if(event->type() == QEvent::KeyPress){
            QKeyEvent *k = static_cast<QKeyEvent *>(event);
            //按下ctrl+enter发消息
            if(k->key() == Qt::Key_Return &&(k->modifiers() & Qt::ControlModifier))
            {
                on_sendButton_clicked();
                return true;
            }
        }
    }
    return false;
#endif
}


question::~question()
{
    delete ui;
}

//处理UDP套接字接收到的数据报
void question::processPendingDatagrams()
{
    //hasPendingDatagrams返回true时表示至少有一个数据报在等待被读取
    while(udpSocket->hasPendingDatagrams())//当UDP套接字中有待处理的数据报时，进入循环
    {
        QByteArray datagram;//用于存储接收到的数据报
        datagram.resize(udpSocket->pendingDatagramSize());   //调整datagram的大小为接收到的数据报的大小
        udpSocket->readDatagram(datagram.data(),datagram.size());//读取UDP套接字中的数据报，并将其存储在datagram中
        QDataStream in(&datagram,QIODevice::ReadOnly);//创建一个只读的QDataStream对象in，用于从datagram中读取数据
        int messageType;
        in >> messageType;//从in中读取一个整数值，表示消息的类型
        QString userName,ID,ipAddress,message;
        QString time = QDateTime::currentDateTime()
                .toString("yyyy-MM-dd hh:mm:ss");//读取当前的时间并转化成括号中的形式
        switch(messageType)
        {
        //如果消息类型是"Message"，即显示发送的消息
        case Message:
            in >> userName >> ID >> ipAddress >> message;//从in中依次读取用户名、ID、IP地址和消息内容
            ui->messageBrowser->setTextColor(Qt::red);//设置消息框的文本颜色为红色
            ui->messageBrowser->setCurrentFont(QFont("Times New Roman",12));//设置消息框的文本字体与字号
            ui->messageBrowser->append("[" + userName + "]" + time);//追加一段文本，下同
            ui->messageBrowser->append(message);
            break;

        //如果消息类型是"NewParticipant"，表示有新的参与者加入
        case NewParticipant:
            in >> userName >> ID >> ipAddress;//从in中依次读取新参与者的用户名、ID和IP地址
            newParticipant(userName,ID,ipAddress);
            break;

        //如果消息类型是"ParticipantLeft"，表示有参与者离开
        case ParticipantLeft:
            in >> userName >> ID;//从in中依次读取离开的参与者的用户名和ID
            participantLeft(userName,ID,time);
        }
    }
}
//发送按钮--槽
void question::on_sendButton_clicked()
{
    sendMessage(Message);
}

//更改输入框字体大小
void question::on_SizeComboBox_currentIndexChanged(const QString &arg1)
{
    ui->messageTextEdit->setFontPointSize(arg1.toDouble());
    ui->messageTextEdit->setFocus();
}


//设置字体时可切换到相应状态
void question::currentFormatChanged(const QTextCharFormat &format)
{
    ui->fontComboBox->setCurrentFont(format.font());
    if(format.fontPointSize() < 9) {
        ui->SizeComboBox->setCurrentIndex(3);
    }
    else {
        ui->SizeComboBox->setCurrentIndex(ui->SizeComboBox
                                          ->findText(QString::number(format.fontPointSize())));
    }
    color = format.foreground().color();
}

//清空聊天记录
void question::on_clearToolBtn_clicked()
{
    ui->messageBrowser->clear();
}


//改变输入框字体
void question::on_fontComboBox_currentFontChanged(const QFont &f)
{
    ui->messageTextEdit->setCurrentFont(f);
    ui->messageTextEdit->setFocus();
}

//字体颜色
void question::on_colorToolBtn_clicked()
{
    color = QColorDialog::getColor(color,this);
    if(color.isValid()) {
        ui->messageTextEdit->setTextColor(color);
        ui->messageTextEdit->setFocus();
    }
}
