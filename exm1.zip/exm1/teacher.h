#ifndef TEACHER_H
#define TEACHER_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QMenu>

#include <QtSql>
#include <QMessageBox>
#include "db.h"
#include "modify_sco.h" //修改成绩

namespace Ui {
class teacher;
}

class teacher : public QWidget
{
    Q_OBJECT

private slots:
    void Init();

    void on_findbutton_clicked();
    void on_selectbutton_clicked();

    void on_modifybutton_clicked();

    void on_refleshbutton_clicked();


public:
    explicit teacher(QWidget *parent = nullptr);
    ~teacher();

private:
    Ui::teacher *ui;
    QSqlDatabase db;
    QString t_name;  //存放老师的姓名

};

#endif // TEACHER_H
