#ifndef STUDENT_H
#define STUDENT_H

#include <QWidget>
#include "teacher.h"
#include "grade.h"
#include "choose.h"//选课
#include "stu_homework.h"//作业
#include "studentaccount.h"//账号管理
#include "competition.h"//竞赛与学术
#include "send_email_ts.h"//邮件
#include "question.h"//答疑
#include <QNetworkInterface>

namespace Ui {
class student;
}

class student : public QWidget
{
    Q_OBJECT

public:
    explicit student(QWidget *parent = nullptr);
    ~student();
    void Init();

private slots:
    void on_scorebutton_clicked();

    void on_signinbutton_clicked();

    void on_choosebutton_clicked();

    void on_homeworkbutton_clicked();

    void on_accountbutton_clicked();

    void on_competitionbutton_clicked();

    void on_emailbutton_clicked();

    void on_startbutton_clicked();

    void on_clearbutton_clicked();

    void on_homeworkbutton_2_clicked();

private:
    Ui::student *ui;
    QSqlDatabase db; //存放数据库信息
    QString t_name;   //存放学生的姓名

};

#endif // STUDENT_H
