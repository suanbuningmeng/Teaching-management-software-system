#ifndef MODIFY_SCO_H
#define MODIFY_SCO_H

#include <QWidget>
#include <QDialog>
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QtSql>
#include <QRegExpValidator>
#include <QTimer>
#include <QMessageBox>
#include <QDebug>
#include "db.h"

namespace Ui {
class modify_sco;
}

class modify_sco : public QWidget
{
    Q_OBJECT

private slots:
    void on_change_ok_clicked();
    void Init();

public:
    explicit modify_sco(QWidget *parent = nullptr);
    ~modify_sco();

private:
    Ui::modify_sco *ui;
    QSqlDatabase db;
};

#endif // MODIFY_SCO_H
