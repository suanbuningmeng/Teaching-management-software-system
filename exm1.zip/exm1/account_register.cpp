#include "account_register.h"
#include "ui_account_register.h"

account_register::account_register(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::account_register)
{
    ui->setupUi(this);
    setWindowTitle("注册");
    Init();
}

account_register::~account_register()
{
    delete ui;
}

void account_register::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::information(this,"提示","链接数据库失败");
        return;
    }
}

void account_register::on_pushButton_OK_clicked()
{

    if(ui->lineEdit_Name->text().isEmpty()
            ||ui->lineEdit_ID->text().isEmpty()
            ||ui->lineEdit_xueyuan->text().isEmpty()
            ||ui->lineEdit_Age->text().isEmpty()
            ||ui->lineEdit_Password->text().isEmpty()
            ||ui->lineEdit_mail->text().isEmpty())
    {
     QMessageBox::warning(this,"注册提示","请填写完整信息");
    }
    else if(ui->lineEdit_Password->text()!=ui->lineEdit_Password_1->text())
    {
     QMessageBox::warning(this,"注册提示","前后密码不一致");
    }
    else
    {
    //注册界面槽函数
        //获取输入信息
        QString _name = ui->lineEdit_Name->text();//注册用户名
        QString _ID= ui->lineEdit_ID->text();//学号
        QString institude=ui->lineEdit_xueyuan->text();//学院
        QString Age=ui->lineEdit_Age->text();//年龄
        QString Password=ui->lineEdit_Password->text();//密码

        QString Mail=ui->lineEdit_mail->text();//邮箱
        QString sex;//性别

        if(ui->radioButton_Man->isChecked())
        {
         sex="男";
        }
        else if(ui->radioButton_Woman->isChecked())
        {
         sex="女";
        }
        else
        {
         QMessageBox::warning(this,"注册提示","请填写性别");
        }
        //查询用户名称是否存在

        QSqlQuery query;
        QString sql = QString("select * from student where name = '%1';").arg(_name);
        if(query.exec(sql))
        {
            if(query.size() >= 1)     //姓名重复
            {
                QMessageBox::warning(this,"注册提示","用户名已注册");
                return;
            }
        }
         sql = QString("select * from student where id = '%1';").arg(_ID);
        if(query.exec(sql))
        {
            if(query.size() >= 1)     //学号重复
            {
                QMessageBox::warning(this,"注册提示","学号已注册");
                return;
            }
        }
            sql = QString("insert into student(id,name,sex,institute,age,password) values('%1','%2','%3','%4','%5','%6')")
                   .arg(_ID)
                   .arg(_name)
                   .arg(sex)
                   .arg(institude)
                   .arg(Age)
                   .arg(Password);

            if(query.exec(sql))
            {
//                QMessageBox::information(this,"注册提示","注册成功");
            }
            else
            {
                QMessageBox::warning(this,"注册提示","注册失败");

            }
            sql = QString("insert into email_form(id,name,email,identify) values('%1','%2','%3','%4')")
                   .arg(_ID)
                   .arg(_name)
                   .arg(Mail)
                   .arg("学生");

            if(query.exec(sql))
            {
                QMessageBox::information(this,"注册提示","注册成功");
            }
            else
            {
                QMessageBox::warning(this,"注册提示","注册失败");
            }
             ui->lineEdit_Name->clear();
             ui->lineEdit_xueyuan->clear();
             ui->lineEdit_Age->clear();
             ui->lineEdit_Password->clear();
             ui->lineEdit_ID->clear();
             ui->lineEdit_mail->clear();
             ui->lineEdit_Password_1->clear();
   }
}
