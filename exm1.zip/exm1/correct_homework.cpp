#include "correct_homework.h"
#include "ui_correct_homework.h"

correct_homework::correct_homework(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::correct_homework)
{
    ui->setupUi(this);
    this->setWindowTitle("作业批改");
    ui->name_box->clear();
    Init();
}

correct_homework::~correct_homework()
{
    delete ui;
}

void correct_homework::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
    students.clear();
    ui->name_box->clear();  //清空作业科目
    QString sql;
    QSqlQuery query;
    sql = QString("select * from exams where hastaken2 = '未批改';");
}

void correct_homework::on_paper_select_clicked()
{
    QSqlQuery query,query1,query2;
    QString sql;
    QString paperid;
    choosepaperid = paperid;
    paperid = ui->paperidlabel->text();
    sql = QString("select * from exams where hastaken2 = '未批改' and paperid = '%1';").arg(paperid);
    students.clear();
    ui->name_box->clear();  //清空作业科目
    if(query.exec(sql))
    {
        while(query.next())
        {
            students.push_back(query.value(1).toString());
        }
    }

    int n = students.size();
    for(int i = 0; i < n ; ++i)
    {
        ui->name_box->addItem(students[i]);
    }

    sql = QString("select * from testpapers where paperid = '%1';").arg(paperid);

    if(query1.exec(sql))
    {
        number.clear();
        questions.clear();
        values.clear();
        query1.first();
        for(int i = 0; i < 5; ++i)
        {
           if(query1.value(i + 1).toString().isEmpty())
           {
               break;//下一个为空直接跳过
           }
           else
           {
               QString v = query1.value(i + 6).toString();//试卷分数压入  v当中
               QString qid = query1.value(i + 1).toString(); //问题id   题目编号压进去

               sql = QString("select * from questions where questionid = '%1';").arg(qid);


               if(!query2.exec(sql))
               {
                  QMessageBox::information(this,"警告","打开失败");
                  return;
               }
               else
               {
                  query2.first();
                  number.push_back(i);    //把当前的题目压入list中
                  questions.push_back(qid);
                  values.push_back(v);    //分数值压入list中
               }
           }
        }
    }
                     id = 0;//记录第几题
                     ui->label_9->setText(QString("第%1题/共%2题").arg(id + 1).arg(number.size()));
                     ui->label_4->setText(QString("本题满分%1分").arg(values[id]));
                     sql = QString("select * from exams where student = '%1' and paperid = '%2';").arg(ui->name_box->currentText()).arg(paperid);
                     query1.exec(sql);
                     query1.next();
                     ui->stu_Answer->setText(query1.value(5 + id).toString()); //学生答案显示出来

                     sql = QString("select * from questions where questionid = '%1';").arg(questions[id]);
                     query1.exec(sql);
                     query1.next();
                     ui->Teacher_Answer->setText(query1.value(7).toString());//正确答案显示出来

                     sql = QString("select * from questions where questionid = '%1';").arg(questions[id]);
                     query1.exec(sql);
                     query1.next();
                     ui->question_Edit->setText(query1.value(2).toString());//题干显示出来
}


void correct_homework::on_Score_put_clicked()
{
    QString sql;
    QSqlQuery query,query1;
    QString Remark=ui->remark_Edit->toPlainText();
    QString paperid;
    paperid = ui->paperidlabel->text();
    //检查分数
    if(ui->Score_Edit->text().isEmpty())
    {
        QMessageBox::information(this,"提示","请输入分数");
        return;
    }
    else if(ui->Score_Edit->text().toInt() > values[id].toInt()
            ||ui->Score_Edit->text() < "0")
    {
        QMessageBox::information(this,"提示","打分不合理");
        return;
    }
    else
    {
        if(id == 4)//评语
        {
            sql = QString("update exams set remark = '%1' where paperid = '%2' and student = '%3';"
                          ).arg(Remark).arg(paperid).arg(ui->name_box->currentText());
            query.exec(sql);
        }
        sql = QString("update exams set score%1 = '%2' where paperid = '%3' and student = '%4';"
                      ).arg(id + 1).arg(ui->Score_Edit->text()).arg(paperid).arg(ui->name_box->currentText());
        if(query.exec(sql))
        {
            QMessageBox::information(this,"提示","打分成功");
            sql = QString("select * from exams where student = '%1' and paperid = '%2';").arg(ui->name_box->currentText()).arg(paperid);
            query1.exec(sql);
            query1.next();
            int score;
            score = query1.value(10).toInt() + query1.value(11).toInt() + query1.value(12).toInt() + query1.value(13).toInt() + query1.value(14).toInt();
            ui->score_label->setText(QString("%1分").arg(score));
            return;
        }
            query.next();
            ui->label_9->setText(QString("第%1题/共%2题").arg(id + 1).arg(number.size()));
            ui->label_4->setText(QString("本题满分%1分").arg(values[id]));
    }
}



void correct_homework::on_nextbutton_clicked()
{
    id++;
    if(id < number.size())
    {
    qDebug()<<id;
    QSqlQuery query1;
    QString sql;
    QString paperid;
    choosepaperid = paperid;
    paperid = ui->paperidlabel->text();
    ui->label_9->setText(QString("第%1题/共%2题").arg(id + 1).arg(number.size()));
    ui->label_4->setText(QString("本题满分%1分").arg(values[id]));
    sql = QString("select * from exams where student = '%1' and paperid = '%2';").arg(ui->name_box->currentText()).arg(paperid);
    query1.exec(sql);
    query1.next();
    ui->stu_Answer->setText(query1.value(5 + id).toString()); //学生答案显示出来

    sql = QString("select * from questions where questionid = '%1';").arg(questions[id]);
    query1.exec(sql);
    query1.next();
    ui->Teacher_Answer->setText(query1.value(7).toString());//正确答案显示出来

    sql = QString("select * from questions where questionid = '%1';").arg(questions[id]);
    query1.exec(sql);
    query1.next();
    ui->question_Edit->setText(query1.value(2).toString());//题干显示出来
    }
    else
    {
    id =4;
    }
}
void correct_homework::Item_Change()
{
    QSqlQuery query;
    QString sql;
    QString paperid;
    choosepaperid = paperid;
    students.clear();
    paperid = ui->paperidlabel->text();
    sql = QString("select * from exams where hastaken2 = '未批改' and paperid = '%1';").arg(paperid);
    if(query.exec(sql))
    {
        while(query.next())
        {
            students.push_back(query.value(1).toString());
            qDebug()<<query.value(1).toString();
        }
    }
    int n = students.size();

    for(int i = 0; i < n ; ++i)
    {
        ui->name_box->addItem(students[i]);
    }

}


void correct_homework::on_surebutton_clicked()
{
    if(!(QMessageBox::information(this,tr("提示"),tr("批改是否完成?"),tr("是"),tr("否"))))
    {
        QString paperid;
        paperid = ui->paperidlabel->text();
        QSqlQuery query;
        QString sql;
        sql = QString("update exams set hastaken2 = '已批改' where paperid = '%1' and student = '%2';"
                      ).arg(paperid).arg(ui->name_box->currentText());
        if(query.exec(sql))
        {
           ui->name_box->clear();
           Item_Change();
        }
    }
}

void correct_homework::on_backbutton_clicked()
{
    if(id >0)
    {
    id--;
    qDebug()<<id;
    QSqlQuery query1;
    QString sql;
    QString paperid;
    choosepaperid = paperid;
    paperid = ui->paperidlabel->text();
    ui->label_9->setText(QString("第%1题/共%2题").arg(id + 1).arg(number.size()));
    ui->label_4->setText(QString("本题满分%1分").arg(values[id]));
    sql = QString("select * from exams where student = '%1' and paperid = '%2';").arg(ui->name_box->currentText()).arg(paperid);
    query1.exec(sql);
    query1.next();
    ui->stu_Answer->setText(query1.value(5 + id).toString()); //学生答案显示出来

    sql = QString("select * from questions where questionid = '%1';").arg(questions[id]);
    query1.exec(sql);
    query1.next();
    ui->Teacher_Answer->setText(query1.value(7).toString());//正确答案显示出来

    sql = QString("select * from questions where questionid = '%1';").arg(questions[id]);
    query1.exec(sql);
    query1.next();
    ui->question_Edit->setText(query1.value(2).toString());//题干显示出来
    }
}
