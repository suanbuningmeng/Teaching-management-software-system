#include "edit_homework.h"
#include "ui_edit_homework.h"

edit_homework::edit_homework(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::edit_homework)
{
    ui->setupUi(this);
    setWindowTitle("添加题库");
    Init();
}

edit_homework::~edit_homework()
{
    delete ui;
}

void edit_homework::Init()//考试管理按钮
{
    ui->stackedWidget->setCurrentIndex(1);//开始设置为创建作业界面
    db=QSqlDatabase::addDatabase("QMYSQL");

    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
    on_questionpushButton_clicked();
}

void edit_homework::on_newpushButton_clicked()
{
    QString sql;
    QSqlQuery query;
    QString questionid,questiontype,question,questionanswer;//一共就四个
    QString A,B,C,D;
    bool ok = true;
    if(ui-> newquestionidlineEdit->text().isEmpty())
    {
        QMessageBox::information(this,"提示","请输入题目编号");
        ok = false;
        return;
    }
    else
    {
        questionid = ui->newquestionidlineEdit->text();
        sql = QString("select * from questions where questionid = '%1';").arg(questionid);
        if(query.exec(sql))
        {
            if(query.size()>0)
            {
                QMessageBox::information(this,"提示","题目编号已使用");
                ok = false;
                return;
            }
        }
    }
    if(ui-> textEdit_qus->toPlainText().isEmpty())//检测题干
    {
        QMessageBox::information(this,"提示","请输入题目题干");
        ok = false;
        return;
    }
    else
    {
        question = ui-> textEdit_qus->toPlainText();//题干获取
    }


    questiontype = ui->comboBox->currentText();//类型保存

    if(questiontype == "选择题")
    {
        if(ui->lineEdit_A->text().isEmpty())//检测A选项
        {
            QMessageBox::information(this,"提示","请输入A选项内容");
            ok = false;
            return;
        }
        else
        {
            A = ui->lineEdit_A->text();
        }
        if(ui->lineEdit_B->text().isEmpty())//检测B选项
        {
            QMessageBox::information(this,"提示","请输入B选项内容");
            ok = false;
            return;
        }
        else
        {
            B = ui->lineEdit_B->text();
        }
        if(ui->lineEdit_C->text().isEmpty())//检测C选项
        {
            QMessageBox::information(this,"提示","请输入C选项内容");
            ok = false;
            return;
        }
        else
        {
            C = ui->lineEdit_C->text();
        }
        if(ui->lineEdit_D->text().isEmpty())//检测D选项
        {
            QMessageBox::information(this,"提示","请输入D选项内容");
            ok = false;
            return;
        }
        else
        {
            D = ui->lineEdit_D->text();
        }
    }
    //判断答案
    if(ui->textEdit_ans->toPlainText().isEmpty())
    {
        QMessageBox::information(this,"提示","请输入正确答案");
        ok = false;
        return;
    }
    else if(questiontype == "选择题"
            &&ui->textEdit_ans->toPlainText()!="A"
            &&ui->textEdit_ans->toPlainText()!="B"
            &&ui->textEdit_ans->toPlainText()!="C"
            &&ui->textEdit_ans->toPlainText()!="D")
    {
        QMessageBox::information(this,"提示","答案应为A/B/C/D");
        ok = false;
        return;
    }
    else if(questiontype == "判断题"
            &&ui->textEdit_ans->toPlainText()!="right"
            &&ui->textEdit_ans->toPlainText()!="wrong")
    {
        QMessageBox::information(this,"提示","答案应为right/wrong");
        ok = false;
        return;
    }

    else
    {
        questionanswer = ui->textEdit_ans->toPlainText();//不是选择判断的话直接把答案    答案存起来
    }

    //检查完毕

    if(ok)
    {
        if(questiontype == "选择题")
        {
            sql = QString("insert into questions values ('%1','%2','%3','%4','%5','%6','%7','%8');"
                          ).arg(questionid).arg(questiontype).arg(question).arg(A).arg(B).arg(C).arg(D).arg(questionanswer);
            if(query.exec(sql))
            {
                QMessageBox::information(this,"提示","新增题目成功");
                on_questionpushButton_clicked();
            }
            else
            {
                QMessageBox::information(this,"提示","新增题目失败");
            }
        }
        else
        {
            sql = QString("insert into questions (questionid,type,question,answer) values ('%1','%2','%3','%4');" // 判断题判断
                          ).arg(questionid).arg(questiontype).arg(question).arg(questionanswer);
            if(query.exec(sql))
            {
                QMessageBox::information(this,"提示","新增题目成功");
                on_questionpushButton_clicked();
            }
            else
            {
                QMessageBox::information(this,"提示","新增题目失败");
            }
        }
    }
}

//全部清零方便增加题目
void edit_homework::on_questionpushButton_clicked()//题目管理按钮
{
    //清屏
    ui->newquestionidlineEdit->clear();
    ui->comboBox->setCurrentIndex(0);
    ui->textEdit_qus->clear();
    ui->textEdit_ans->clear();
    ui->lineEdit_A->clear();
    ui->lineEdit_B->clear();
    ui->lineEdit_C->clear();
    ui->lineEdit_D->clear();

}

void edit_homework::on_search_button_clicked()
{
    QString sql;
    QSqlQuery query;
    QString questionid,questiontype,question,questionanswer;
    QString A,B,C,D;
    bool ok = true;
    if(ui->newquestionidlineEdit->text().isEmpty())
    {
        QMessageBox::information(this,"提示","请输入题目编号");
        ok = false;
        return;
    }
    else
    {
        questionid = ui->newquestionidlineEdit->text();
        sql = QString("select * from questions where questionid = '%1';").arg(questionid);
        if(query.exec(sql))
        {
            if(query.size() < 1)
            {
                QMessageBox::information(this,"提示","题目不存在");
                ok = false;
                return;
            }
            else
            {
                query.next();
                questiontype = query.value(1).toString();
                question = query.value(2).toString();
                A = query.value(3).toString();
                B = query.value(4).toString();
                C = query.value(5).toString();
                D = query.value(6).toString();
                questionanswer = query.value(7).toString();
            }
        }
    }
    if(ok)
    {
       // ui->questiontypelineEdit->setText(questiontype);

        ui->textEdit_qus->setText(questiontype+":");//问题类型  问题

        ui->textEdit_qus->append(question);
//        ui->textEdit_qus->setText(question);
        ui->textEdit_ans->setText(questionanswer);
        if(questiontype == "选择题")
        {
            ui->lineEdit_A->setText(A);
            ui->lineEdit_B->setText(B);
            ui->lineEdit_C->setText(C);
            ui->lineEdit_D->setText(D);
        }
        else
        {
            ui->lineEdit_A->clear();
            ui->lineEdit_B->clear();
            ui->lineEdit_C->clear();
            ui->lineEdit_D->clear();
        }
    }
}

void edit_homework::on_next_page_clicked()
{
        ui->stackedWidget->setCurrentIndex(1);
        ui->lineEdit->clear();
        ui->lineEdit_num->clear();

        ui->comboBox_1->clear();
        ui->comboBox_2->clear();
        ui->comboBox_3->clear();
        ui->comboBox_4->clear();
        ui->comboBox_5->clear();

        ui->lineEdit_1->clear();
        ui->lineEdit_2->clear();
        ui->lineEdit_3->clear();
        ui->lineEdit_4->clear();
        ui->lineEdit_5->clear();


        //记录所有题目
        QString sql;
        QSqlQuery query;
        vector<QString> ques;
        sql = QString("select * from questions;");
        if(query.exec(sql))
        {
            while(query.next())
            {
                ques.push_back(query.value(0).toString());
            }
        }
        for(int i = 0; i < query.size(); ++i)
        {
            ui->comboBox_1->addItem(ques[i]);
            ui->comboBox_2->addItem(ques[i]);
            ui->comboBox_3->addItem(ques[i]);
            ui->comboBox_4->addItem(ques[i]);
            ui->comboBox_5->addItem(ques[i]);
        }//每个item  加入问题的编号
}


void edit_homework::on_pushButton_clicked()
{
    QString sql;
    QSqlQuery query;
    QString paperid,ques1,ques2,ques3,ques4,ques5,value1,value2,value3,value4,value5;//五个问题  5个值
    int quesnum;
    bool ok = true;
    //检查试卷编号
    if(ui->lineEdit->text().isEmpty())
    {
        QMessageBox::information(this,"提示","请输入试卷编号");
        ok = false;
        return;
    }
    else
    {
        sql = QString("select * from testpapers where paperid = '%1';").arg(ui->lineEdit->text());
        if(query.exec(sql))
        {
            if(query.size() > 0)
            {
                QMessageBox::information(this,"提示","试卷编号已使用");//试卷编号管理题库
                ok = false;
                return;
            }
            else
            {
                paperid = ui->lineEdit->text();
            }
        }
    }
    //检查题目数量
    if(ui->lineEdit_num->text().toInt() <= 0
            || ui->lineEdit_num->text().toInt() > 5)
    {
        QMessageBox::information(this,"提示","题目数量不合规");
        ok = false;
        return;
    }
    else
    {
        quesnum = ui->lineEdit_num->text().toInt();        //统计题目数量
    }
    //检查分值
    if(quesnum >= 1)
    {
        if(ui->lineEdit_1->text().isEmpty())
        {
            QMessageBox::information(this,"提示","请输入第1题的分值");
            ok = false;
            return;
        }
        else if(ui->lineEdit_1->text().toInt() <= 0
                || ui->lineEdit_1->text().toInt() > 100)
        {
            QMessageBox::information(this,"提示","第1题的分值设置不合理（应在1-100之间）");
            ok = false;
            return;
        }
        else
        {
            value1 = ui->lineEdit_1->text();
        }
    }
    if(quesnum >= 2)
    {
        if(ui->lineEdit_2->text().isEmpty())
        {
            QMessageBox::information(this,"提示","请输入第2题的分值");
            ok = false;
            return;
        }
        else if(ui->lineEdit_2->text().toInt() <= 0
                || ui->lineEdit_2->text().toInt() > 100)
        {
            QMessageBox::information(this,"提示","第2题的分值设置不合理（应在1-100之间）");
            ok = false;
            return;
        }
        else
        {
            value2 = ui->lineEdit_2->text();
        }
    }
    //执行这条语句的时候 上面两条语句必执行
    if(quesnum >= 3)
    {
        if(ui->lineEdit_3->text().isEmpty())
        {
            QMessageBox::information(this,"提示","请输入第3题的分值");
            ok = false;
            return;
        }
        else if(ui->lineEdit_3->text().toInt() <= 0
                || ui->lineEdit_3->text().toInt() > 100)
        {
            QMessageBox::information(this,"提示","第3题的分值设置不合理（应在1-100之间）");
            ok = false;
            return;
        }
        else
        {
            value3 = ui->lineEdit_3->text();
        }
    }
    if(quesnum >= 4)
    {
        if(ui->lineEdit_4->text().isEmpty())
        {
            QMessageBox::information(this,"提示","请输入第4题的分值");
            ok = false;
            return;
        }
        else if(ui->lineEdit_4->text().toInt() <= 0
                || ui->lineEdit_4->text().toInt() > 100)
        {
            QMessageBox::information(this,"提示","第4题的分值设置不合理（应在1-100之间）");
            ok = false;
            return;
        }
        else {
            value4 = ui->lineEdit_4->text();
        }
    }
    if(quesnum == 5)
    {
        if(ui->lineEdit_5->text().isEmpty())
        {
            QMessageBox::information(this,"提示","请输入第5题的分值");
            ok = false;
            return;
        }
        else if(ui->lineEdit_5->text().toInt() <= 0
                || ui->lineEdit_5->text().toInt() > 100)
        {
            QMessageBox::information(this,"提示","第5题的分值设置不合理（应在1-100之间）");
            ok = false;
            return;
        }
        else
        {
            value5 = ui->lineEdit_5->text();
        }
    }

    ques1 = ui->comboBox_1->currentText();
    ques2 = ui->comboBox_2->currentText();
    ques3 = ui->comboBox_3->currentText();
    ques4 = ui->comboBox_4->currentText();
    ques5 = ui->comboBox_5->currentText();

    if(ok)
    {
        if(quesnum == 1)
        {
            sql = QString("insert into testpapers (paperid , question1id, value1) values ('%1','%2','%3');"
                          ).arg(paperid).arg(ques1).arg(value1);
            if(query.exec(sql))
            {
                QMessageBox::information(this,"提示","新增试卷成功");
                on_next_page_clicked();
            }
        }
        if(quesnum == 2)
        {
            sql = QString("insert into testpapers (paperid,question1id, value1,question2id,value2) values ('%1','%2','%3','%4','%5');"
                          ).arg(paperid).arg(ques1).arg(value1).arg(ques2).arg(value2);
            if(query.exec(sql))
            {
                QMessageBox::information(this,"提示","新增试卷成功");
                on_next_page_clicked();
            }
        }
        if(quesnum == 3)
        {
            sql = QString("insert into testpapers (paperid,question1id, value1,question2id,value2,question3id,value3) "
                          "values ('%1','%2','%3','%4','%5','%6','%7');"
                          ).arg(paperid).arg(ques1).arg(value1).arg(ques2).arg(value2).arg(ques3).arg(value3);
            if(query.exec(sql))
            {
                QMessageBox::information(this,"提示","新增试卷成功");
                on_next_page_clicked();
            }
        }
        if(quesnum == 4)
        {
            sql = QString("insert into testpapers "
                          "(paperid , question1id, value1,question2id,value2,question3id,value3,"
                          "question4id,value4) "
                          "values ('%1','%2','%3','%4','%5','%6','%7','%8','%9');"
                          ).arg(paperid).arg(ques1).arg(value1).arg(ques2).arg(value2).arg(ques3).arg(value3)
                    .arg(ques4).arg(value4);
            if(query.exec(sql))
            {
                QMessageBox::information(this,"提示","新增试卷成功");
                on_next_page_clicked();
            }
        }
        if(quesnum == 5)
        {
            sql = QString("insert into testpapers "
                          "(paperid , question1id, value1,question2id,value2,question3id,value3,"
                          "question4id,value4,question5id,value5) "
                          "values ('%1','%2','%3','%4','%5','%6','%7','%8','%9','%10','%11');"
                          ).arg(paperid).arg(ques1).arg(value1).arg(ques2).arg(value2).arg(ques3).arg(value3)
                    .arg(ques4).arg(value4).arg(ques5).arg(value5);
            if(query.exec(sql))
            {
                QMessageBox::information(this,"提示","新增试卷成功");
                on_next_page_clicked();
            }
        }
    }
}

void edit_homework::on_delet_page_2_clicked()
{
    if(!(QMessageBox::information(this,tr("提示"),tr("确定删除试卷?"),tr("是"),tr("否"))))
    {
        QString sql;
        QSqlQuery query;
        QString paperid;
        paperid = ui->lineEdit->text();
        sql = QString("delete from testpapers where paperid = '%1';").arg(paperid);
        if(query.exec(sql))
        {
            QMessageBox::information(this,"提示","删除成功");
            on_next_page_clicked();
        }
    }
}
void edit_homework::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}



void edit_homework::on_returnbutton_clicked()
{
    send_homework *Send_homework=new send_homework;
    Send_homework->show();
    this->hide();
}
