#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;
#include <WinSock2.h>
#include <QDebug>
#include "base64.h"
#pragma comment(lib,"ws2_32.lib")
#include "EMail.h"
#include <QDebug>

//SMTP
//网络
//int main()
//{
void send_EMail( string _Username, string _Password,string _From,string _receive,string _Suject,string _Text,string _ip)
{
//打开网络权限
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2,2),&wsaData);
//连接上网易的邮箱服务器
//smtp.163.com
//创建socket
//AF_INET 协议地址簇  IPV4
    //TCP SOCK_STREAM 流式套接字
     SOCKET sock=socket(AF_INET,SOCK_STREAM,0);
/*
网易的Ip：103.74.29.40
*/
     struct sockaddr_in local;// 服务端地址信息的数据结构。
     local.sin_family=AF_INET;// 协议族，在socket编程中只能是AF_INET
     local.sin_port=htons(25);// 指定通信端口
     memcpy(&local.sin_addr,gethostbyname(_ip.c_str())->h_addr,sizeof(struct in_addr));//指定Ip为103.74.29.40
     //链接
     if(connect(sock,(struct sockaddr*)&local,sizeof(struct sockaddr))==-1)
     {
         printf("fail to connect");
         return;
     }
    //printf("success to connect\n");

//链接成功后会有一个返回值，打印出来
    char buffer[1024]={ 0 };
    recv(sock,buffer,1024,0);
 //   printf("%s\n",buffer);
//链接成功后会有一个返回值，打印出来

//链接成功后还要互发一些东西确认    返回ok 250
    string sendBuffer="HELO MSG\r\n";
    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);

    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);
  //  printf("%s\n",buffer);


    sendBuffer="AUTH LOGIN\r\n";
    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);

    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);

    char src[50] ={0};
    strcpy(src, _Username.c_str());

    //src =_Username;
    int src_len = strlen(src);

    char base64[1024] = {0};

    base64_encode(src,src_len,base64);

    sendBuffer=base64;//C++
    sendBuffer+="\r\n";
    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);

    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);
  //  printf("%s\n",buffer);

    char sr[50] ={0};
    strcpy(sr, _Password.c_str());

    int sr_len = strlen(sr);

    memset(base64,0,1024);//清空发送缓冲区，重新填值

    base64_encode(sr,sr_len,base64);

    sendBuffer=base64;//C++
    sendBuffer+="\r\n";
    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);

    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);
   // printf("%s\n",buffer);

//以上返回 235 Authentication successful   就是身份验证成功 就是登上去了


//发送 发件人邮箱信息
    sendBuffer="MAIL FROM:<";
    sendBuffer+= _Username;
    sendBuffer+=">\r\n";//自定义

    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);//发送

    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);
    printf("%s\n",buffer);//打印、接收、验证


//发送 收件人邮箱信息
//    sendBuffer="RCPT TO:<1367301986@qq.com>\r\n";//自定义
    sendBuffer="RCPT TO:<";
    sendBuffer+= _receive;
    sendBuffer+=">\r\n";//自定义


    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);//发送

    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);
    printf("%s\n",buffer);//打印、接收、验证


    //发送 DATA
        sendBuffer="DATA\r\n";//自定义

        send(sock,sendBuffer.c_str(),sendBuffer.length(),0);//发送

        memset(buffer,0,1024);//清空发送缓冲区，重新填值
        recv(sock,buffer,1024,0);
        printf("%s\n",buffer);//打印、接收、验证

//返回   354 End data with <CR><LF>.<CR><LF>   就是发数据的时候，结尾用   \r\n


    //"From:123456\r\nSubject:\r\n\r\n123456789\r\n\r\n\r\n.\r\n";

    sendBuffer="From:";
    sendBuffer+= _From;//就不自定义了呗，这里自定义就发送不成功，会被系统退回
    sendBuffer+="\r\nSubject:";
    sendBuffer+= _Suject   ;//标题
    sendBuffer+="\r\n\r\n";
    sendBuffer+= _Text ;//正文
    sendBuffer+="\r\n\r\n\r\n.\r\n";//结束符

    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);//发送
    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);
   // printf("%s\n",buffer);//打印、接收、验证

//退出服务器      每次成功发送后都应该退出
    sendBuffer="Quit\r\n";
    send(sock,sendBuffer.c_str(),sendBuffer.length(),0);//发送
    memset(buffer,0,1024);//清空发送缓冲区，重新填值
    recv(sock,buffer,1024,0);
    printf("%s\n",buffer);//打印、接收、验证
//退出服务器

}

