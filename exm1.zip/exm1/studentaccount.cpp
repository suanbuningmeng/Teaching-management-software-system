#include "studentaccount.h"
#include "ui_studentaccount.h"

studentaccount::studentaccount(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::studentaccount)
{
    ui->setupUi(this);
    setWindowTitle("账号管理");
    Init();
}

studentaccount::~studentaccount()
{
    delete ui;
}

void studentaccount::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");

    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);

    if(!db.open())
        {
            QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                                 +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
            return;
        }

        QSqlQuery query;
        query.prepare("SELECT id,name,password FROM student WHERE id=:ID");
        query.bindValue(":ID",LoginId);
        query.exec();
        query.first();
        ui->editId->setText(query.value("id").toString());
        ui->editName->setText(query.value("name").toString());
        ui->editPassword->setText(query.value("password").toString());

}

void studentaccount::on_pushButton_clicked()
{
    if(ui->newPassword->text() != ui->surePassword->text())
    {
        QMessageBox::information(this, "提示", "前后密码输入不一致");
    }
    else
    {
    QSqlQuery modify;
    modify.prepare("UPDATE student SET password=? WHERE id=?");
    modify.bindValue(0,ui->newPassword->text());
    modify.bindValue(1,LoginId);
    if(modify.exec())
        QMessageBox::information(this, "提示", "密码修改成功");
    else
        QMessageBox::warning(this,"错误","修改密码失败,错误信息\n"
                             +modify.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
    }
}
