#include "send_homework.h"
#include "edit_homework.h"
#include "ui_send_homework.h"

send_homework::send_homework(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::send_homework)
{
    ui->setupUi(this);
    setWindowTitle("发布作业");
    Init();
}

send_homework::~send_homework()
{
    delete ui;
}

void send_homework::Init()//考试管理按钮
{
    db=QSqlDatabase::addDatabase("QMYSQL");

    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
    QString sql;
    QSqlQuery query;
    vector<QString> subjects;//科目列表
    vector<QString> students;//学生列表

//根据登录id  确定名字
   sql = QString("select * from teacher where id = '%1';").arg(LoginId);

   if(query.exec(sql))
   {
       query.first();
       t_name=query.value("name").toString();
   }
   query.clear();
//根据登录id  确定名字



    ui->comboBox_2->clear();//清空参与学生
    ui->comboBox->clear();  //清空作业科目
    ui->lineEdit->clear();  //清空作业名

    ui->comboBox_2->addItem("所有学生");   //先加一个所有学生

      sql = QString("select * from course where teacher = '%1';").arg(t_name);


    if(query.exec(sql))
    {
        while(query.next())
        {
            subjects.push_back(query.value(1).toString());
            qDebug()<<query.value(1).toString();
        }
    }

    int n = subjects.size();
    for(int i = 0; i < n ; ++i)
    {
        ui->comboBox->addItem(subjects[i]);
    }
}

void send_homework::on_startbutton_clicked()
{
    if(!(QMessageBox::information(this,tr("提示"),tr("确定发布作业?"),tr("是"),tr("否"))))
    {
        bool ok = true;
        QString subject,examlength,paperid;
        QString studentid,studentname;
        ui->comboBox->currentText();

        subject = ui->lineEdit->text();
                //ui->subject_box->currentText();       //作业科目获取
        studentid = ui->comboBox_2->currentText();//默认所有学生
        examlength = QString("60");//这里先默认60min

        paperid = ui->lineEdit->text();     //作业试卷名

        if(ui->lineEdit->text().isEmpty())
        {
            ok = false;
            QMessageBox::information(this,"提示","请输入试卷编号");
            return;
        }

        if(ok)
        {
            //先判断试卷是否存在
            QString sql;
            QSqlQuery query;
            sql = QString("select * from testpapers where paperid = '%1';").arg(paperid);
            if(query.exec(sql))
            {
                if(query.size() < 1)
                {
                    QMessageBox::information(this,"提示","试卷编号不存在");
                    return;
                }
            }
            if(studentid == "所有学生")
            {
                //查询记录所有学生
                vector<QString> students;
                studentsofexam.clear();


                //选出考试的学生


                query.prepare("SELECT s.name,s.id from scourse e,student s,course c"//选共同点
                   " where e.sid=s.id and c.id=e.cid and c.teacher=:teach_name and c.name=:ke_name");//选出学生和老师和这门课的共同点，老师id唯一，意思是选出这个老师下的这个课的所有学生

                query.bindValue(":teach_name",t_name);

                query.bindValue(":ke_name",ui->comboBox->currentText());


                if(!query.exec())
                {
                    qDebug()<<"error";
                }

//学生名字直接压入list
                while(query.next())
                {
                 //qDebug()<<query.value("name").toString();
                  students.push_back(query.value("name").toString());
                  studentsofexam.push_back(query.value("name").toString());
                }

//查看试卷发布对象
                query.first();//直接指向结果集的第一条
                QSqlQueryModel *c_model = new QSqlQueryModel;
                c_model->setQuery(query);
                ui->tableView->setModel(c_model);

                int n = students.size();
                for(int i = 0; i < n; ++i)
                {
                    sql = QString("insert into exams (subject,student,length,paperid,hastaken,hastaken2) values ('%1','%2','%3','%4','未参加','未批改');"
                                  ).arg(subject).arg(students[i]).arg(examlength).arg(paperid);
                    if(query.exec(sql))
                    {

                    }
                    else
                    {
                        ok = false;
                    }
                }
            }//以上是所有学生操作
            else
            {
                studentsofexam.clear();
                studentsofexam.push_back(studentid);//item  里面获取的学生
                sql = QString("insert into exams (subject,student,length,paperid,hastaken,hastaken2) values('%1','%2','%3','%4','未参加','未批改');"
                              ).arg(subject).arg(studentid).arg(examlength).arg(paperid);
                if(query.exec(sql))
                {

                }
                else
                {
                    ok = false;
                }
            }
        }

        if(ok)
        {
            QMessageBox::information(this,"提示","作业发布成功");
        }
        else
        {
            QMessageBox::information(this,"提示","作业发布失败");
        }
}
}

void send_homework::on_set_homeworkbutton_clicked()
{
    edit_homework *r=new edit_homework;
    r->show();
    Init();
}


