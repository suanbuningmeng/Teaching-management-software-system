#ifndef ACCOUNT_REGISTER_H
#define ACCOUNT_REGISTER_H

#include <QWidget>
#include <QRegExpValidator>
#include <QSqlQuery>
#include <QMessageBox>
#include <QDebug>
#include <QDate>
#include "db.h"
#include <QDialog>
#include <QSqlDatabase>

namespace Ui {
class account_register;
}

class account_register : public QWidget
{
    Q_OBJECT

private slots:
    void on_pushButton_OK_clicked();
    void Init();//初始化

public:
    explicit account_register(QWidget *parent = nullptr);
    ~account_register();   

private:
    Ui::account_register *ui;
    QSqlDatabase db;
};

#endif // ACCOUNT_REGISTER_H
