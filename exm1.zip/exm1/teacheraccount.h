#ifndef TEACHERACCOUNT_H
#define TEACHERACCOUNT_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QSqlQuery>
#include "db.h"
#include <QtSql>
#include <QMessageBox>
#include <QDataWidgetMapper>

namespace Ui {
class teacheraccount;
}

class teacheraccount : public QWidget
{
    Q_OBJECT

private slots:
    void Init();

    void on_pushButton_clicked();

public:
    explicit teacheraccount(QWidget *parent = nullptr);
    ~teacheraccount();

private:
    Ui::teacheraccount *ui;
    QSqlDatabase db;
};

#endif // TEACHERACCOUNT_H
