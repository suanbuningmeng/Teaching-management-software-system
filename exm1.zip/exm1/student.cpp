#include "student.h"
#include "ui_student.h"

student::student(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::student)
{
    ui->setupUi(this);
    setWindowTitle("学生");

    Init();//初始化
}

student::~student()
{
    delete ui;
}

void student::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    QString sql;
    QSqlQuery query;


    query.prepare("SELECT name FROM student WHERE id=:ID");//根据学生的id找出学生的姓名
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();
    //qDebug()<<"or here";
    t_name = query.value("name").toString();//用id把学生姓名找出来

    ui->comboBox->clear();

    int examsnum = 0;
    sql = QString("select * from exams where student = '%1' and hastaken = '未参加';").arg(t_name);

    if(query.exec(sql))
    {
        examsnum = query.size();
        while(query.next())
        {
            QString a;
            a = query.value(0).toString();//课程信息
            ui->comboBox->addItem(a);//把未完成的作业都移到item 里面
        }
    }

//签到提醒
    sql = QString("select * from scourse where sid = '%1' and Attend_Status = '未签到';").arg(LoginId);
    if(query.exec(sql))//如果学生有一门课没有签到则触发提醒
    {
        examsnum = query.size();
        if(examsnum)
        {
        QMessageBox::information(this,"提醒","你收到了一份签到");
        }
    }
//签到提醒
}

void student::on_scorebutton_clicked()
{
    grade *Grade=new grade;
    Grade->show();
}

void student::on_signinbutton_clicked()
{
    QString sql;
    QSqlQuery query;
    QString str="未签到";
    QString Stu_id;
    sql = QString("select * from scourse where Attend_Status= '%1' and sid = '%2';"

                  ).arg(str).arg(LoginId);
    query.exec(sql);
        if(query.size() < 1)
        {
             QMessageBox::information(this,"提示","你已经签到");
             return;
        }
        else
        {
            str="已签到";
            sql = QString("update scourse set Attend_Status= '%1' where sid = '%2';"

                  ).arg(str).arg(LoginId);

            if(!query.exec(sql))
            {
               qDebug()<<"error";
               return;
            }
            else
            {
               QMessageBox::information(this,"提示","签到成功");
            }
        }
}

void student::on_choosebutton_clicked()
{
    choose *Choose=new choose;
    Choose->show();
}

void student::on_homeworkbutton_clicked()
{
    if(ui->comboBox->currentText().isNull())
    {
        QMessageBox::warning(this,"提示","作业已经写完了，别再卷了！！！");
        return;
    }
    QString subject = ui->comboBox->currentText();
    QString sql;
    QSqlQuery query;
    QString paperid;
    sql = QString("select * from exams where student = '%1' and subject = '%2' and hastaken = '未参加';").arg(t_name).arg(subject);
    if(query.exec(sql))
    {
        query.next();
        paperid = query.value(3).toString();
    }
    //向服务器发送开始考试消息
    // this->hide();
    stu_homework *e = new stu_homework(t_name,paperid);//通信套接字名字  试卷编号
    e->show();
    this->hide();
}

void student::on_accountbutton_clicked()
{
    studentaccount *Studentaccount=new studentaccount;
    Studentaccount->show();
}

void student::on_competitionbutton_clicked()
{
    competition *Competition=new competition;
    Competition->show();
}

void student::on_emailbutton_clicked()
{
    send_email_ts *Send_email_ts=new send_email_ts;
    Send_email_ts->show();
}

void student::on_startbutton_clicked()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                            +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
    QSqlQuery query;
    query.prepare("SELECT id,name,identify FROM email_form WHERE id=:ID");
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();
    t_name =query.value("name").toString(); //根据学号获取姓名

    User users;
    users.id = LoginId;    //ID号
    users.name=t_name;

    QList<QHostAddress>list = QNetworkInterface::allAddresses();//获取本地主机的所有IP地址，并将其存储在list变量中
    foreach(QHostAddress address,list)
     {
        if(address.protocol() == QAbstractSocket::IPv4Protocol && address.toString()!="127.0.0.1")
            users.address =address.toString() ;//将IPv4地址保存在users结构体中的address成员变量中
     }

    question *Question;
    Question= new question(0,users);//使用UDP协议进行答疑聊天
    Question->show();    //答疑界面显示
}

void student::on_clearbutton_clicked()
{
    Init();//初始化
}

void student::on_homeworkbutton_2_clicked()
{

}
