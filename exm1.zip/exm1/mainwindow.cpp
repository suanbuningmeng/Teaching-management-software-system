#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QSqlDatabase>   //连接数据库
#include<QDebug>
#include<QMessageBox>    //消息框
#include<QSqlError>
#include<QSqlQuery>
#include<QVariantList>
#include<QSqlRecord>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("信息管理");

    //打印Qt支持的数据库驱动
    qDebug()<<QSqlDatabase::drivers();

    //获取数据库对象
    QSqlDatabase db=QSqlDatabase::addDatabase("QMYSQL");

    //配置数据库
    db.setHostName("localhost");
    db.setUserName("root");
    db.setPassword("1234");
    db.setDatabaseName("data");

    //打开数据库
    if(db.open()==false)
    {
        QMessageBox::warning(this,"失败",db.lastError().text());
        return;
    }

    //创建model对象
    model= new QSqlTableModel(this);
    //model存储数据库数
    //view 显示和修改数据

    //指定数据库
    model->setTable("student");

    //把model和view关联
    ui->tableView->setModel(model);



    //显示model里的数据
    model->select();

    //修改字段名
    model->setHeaderData(0,Qt::Horizontal,"学号");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"年龄");
    model->setHeaderData(3,Qt::Horizontal,"成绩");
    model->setHeaderData(4,Qt::Horizontal,"班级");
    model->setHeaderData(5,Qt::Horizontal,"学院");
    model->setHeaderData(6,Qt::Horizontal,"考勤");


    //修改model编辑模式
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    ui->stackedWidget->setCurrentIndex(0);
    /*
    //设置view中的数据库不允许修改
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    */
    ui->comboBox->addItem("学号");
    ui->comboBox->addItem("姓名");
    ui->tableView->hideColumn(6);//隐藏考勤信息
    ui->tableView->hideColumn(5);//隐藏学院信息
    ui->tableView->hideColumn(4);//隐藏班级信息

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_findbutton_clicked()//查找学生信息
{
    if(i == 0)
    {
    QString id = ui->lineEdit->text();
    QString sql=QString("id='%1'").arg(id);

    //where
    model->setFilter(sql);
    model->select();
    model->submitAll();
    }
    else
    {
    QString name=ui->lineEdit->text();
    QString sql=QString("name='%1'").arg(name);

    //where
    model->setFilter(sql);
    model->select();
    model->submitAll();
    }

}

void MainWindow::on_addbutton_clicked()//添加学生信息
{
    //获取空记录
    QSqlRecord record = model->record();
    //获取行号
    int row = model->rowCount();

    //在最后一行插入空记录
    model->insertRecord(row,record);
    model->submitAll();
}

void MainWindow::on_buttondel_clicked()//删除学生信息
{
    //获取选中的model
    QItemSelectionModel *sModel=ui->tableView->selectionModel();
    //获取选中model里的索引
    QModelIndexList list=sModel->selectedRows();
    for(int i=0;i!=list.size();i++)
    {
        model->removeRow(list.at(i).row());
    }
    model->submitAll();
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_comboBox_currentIndexChanged(const QString &arg1)
{
    if(ui->comboBox->currentIndex() == 0)
        {
            i = 0;
        }
        else if(ui->comboBox->currentIndex()==1)
        {
            i = 1;
        }
}

void MainWindow::on_incbutton_clicked()//排序
{
     model->submitAll();
     model->sort(3,Qt::DescendingOrder);//表格第四列按照降序排序
     model->submitAll();

}


void MainWindow::on_exitbutton_clicked()
{

}

void MainWindow::on_emailbutton_clicked()
{
      email_1.show();
}


void MainWindow::on_stubutton_clicked()
{
      ui->tableView->hideColumn(3);//隐藏成绩信息
      ui->tableView->showColumn(4);//显示班级信息
      ui->tableView->showColumn(5);//显示学院信息
      ui->tableView->showColumn(6);//显示考勤信息
}
