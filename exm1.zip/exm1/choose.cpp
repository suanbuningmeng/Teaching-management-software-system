#include "choose.h"
#include "ui_choose.h"

choose::choose(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::choose)
{
    ui->setupUi(this);
    setWindowTitle("选课");
    Init();
}

void choose::Init()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    openTable();
}
void choose::on_deletebutton_clicked()
{
    if(ui->input_lesson->text()==nullptr)
    {
        QMessageBox::critical(this,"错误","未填入课程号\n"
                              ,QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    QString _cid=ui->input_lesson->text();
    QSqlQuery query;
    query.prepare("SELECT id,name,institute,sex,age FROM student WHERE id=:ID");
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();
    //qDebug()<<"or here";
    QString _id = query.value("id").toString();//用名字把学生id找出来

    QSqlQuery query1;
    query1.prepare("select cid FROM scourse "
                        "WHERE cid=:cid and sid=:sid");
          query1.bindValue(":cid", _cid);
          query1.bindValue(":sid", LoginId);
     query1.exec();
     query1.first();

     QString _tt = query1.value("cid").toString();
     qDebug()<<_tt;

     if(_tt==nullptr)
     {
         QMessageBox::critical(this,"错误","填入课程号错误\n"
                               ,QMessageBox::Ok,QMessageBox::NoButton);
         return;
     }

     query.prepare("DELETE FROM scourse "
                         "WHERE cid=:cid and sid=:sid");
           query.bindValue(":cid", _cid);
           query.bindValue(":sid", LoginId);//删除学生选择的这类课程
     query.exec();
     QMessageBox::information(this,"提示","退课成功\n"
                           ,QMessageBox::Ok,QMessageBox::NoButton);
     Init();
}

void choose::on_closebutton_clicked()
{
    this->close();
}
void choose::on_selectbutton_clicked()
{

    if(ui->input_lesson->text()==nullptr)
    {
        QMessageBox::critical(this,"错误","未填入课程号\n"
                              ,QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    QString _cid=ui->input_lesson->text();
    QSqlQuery query;
    query.prepare("SELECT id,name,institute,sex,age FROM student WHERE id=:ID");
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();
    //qDebug()<<"or here";
    QString _id = query.value("id").toString();

    query.prepare("INSERT INTO scourse (cid,sid, grade, credit) "
                        "VALUES (:cid, :sid, null,null)");
          query.bindValue(":cid", _cid);//选择这门课就把选择这课程的学号的和课程id绑定在另一张表上
          query.bindValue(":sid", LoginId);
     if(!query.exec())
     {
         QMessageBox::critical(this,"错误","填入课程号错误\n"
                               ,QMessageBox::Ok,QMessageBox::NoButton);
         return;
     }
     Init();
     QMessageBox::information(this,"提示","选课成功\n"
                           ,QMessageBox::Ok,QMessageBox::NoButton);
}

void choose::openTable()
{
    //学生基本信息
    QSqlQuery query,query1;
    query.prepare("SELECT id,name,institute,sex,age FROM student WHERE id=:ID");
    query.bindValue(":ID",LoginId);
    query.exec();
    query.first();

    query1.clear();
    QSqlQueryModel *s_model = new QSqlQueryModel;

    query1.prepare("select cid,name,c.credit,c.institute,c.teacher from scourse s,course c "
                      "where s.sid=:ID and s.cid=c.id");

    query1.bindValue(":ID",LoginId);

    if(!query1.exec())
    {
        qDebug()<<query1.size();
        qDebug()<<"query1.size() error";
    }
    s_model->setQuery(query1);
    s_model->setHeaderData(0,Qt::Horizontal,"课程号");
    s_model->setHeaderData(1,Qt::Horizontal,"课程名");
    s_model->setHeaderData(2,Qt::Horizontal,"学分");
    s_model->setHeaderData(3,Qt::Horizontal,"学院");
    s_model->setHeaderData(4,Qt::Horizontal,"教师");
    ui->selected_lesson->setModel(s_model);

    //可选课程
    query1.prepare("select id,name,credit,institute,teacher from course "
                      "where id not in (select cid from  scourse where sid=:ID)");
    query1.bindValue(":ID",LoginId);
    if(!query1.exec())
    {
        qDebug()<<"query1.size() error";
    }
    QSqlQueryModel *c_model = new QSqlQueryModel;
    c_model->setQuery(query1);
    c_model->setHeaderData(0,Qt::Horizontal,"课程号");
    c_model->setHeaderData(1,Qt::Horizontal,"课程名");
    c_model->setHeaderData(2,Qt::Horizontal,"学分");
    c_model->setHeaderData(3,Qt::Horizontal,"学院");
    c_model->setHeaderData(4,Qt::Horizontal,"教师");
    ui->canSelect_lesson->setModel(c_model);


}

void choose::on_refresh_clicked()
{
    Init();
}

void choose::on_pushButton_2_clicked()
{
    vector<QString> Stu_id;//科目列表

    QSqlQuery query,query1;
    QString _cid;
    query.prepare("SELECT id,name,institute,sex,age FROM student");

    query.exec();

    while(query.next())
    {
        Stu_id.push_back(query.value("id").toString());//名字依次压进去
        //qDebug()<<query.value("id").toString();
    }

   int _size;
   _size=Stu_id.size();

   for(int i=0;i<_size;i++)
   {
       //可选课程
      query1.clear();

       query1.prepare("select id,name,credit,institute,teacher from course "
                         "where id not in (select cid from  scourse where sid=:ID)");

       query1.bindValue(":ID",Stu_id[i]);
       if(!query1.exec())
       {
           qDebug()<<"query1.size() error";
       }//把学生没选择的课程选出来
       while(query1.next())
       {
           _cid=query1.value("id").toString();
           query.prepare("INSERT INTO scourse (cid,sid, grade, credit) "
                               "VALUES (:cid, :sid, null,null)");
                 query.bindValue(":cid", _cid);//选择这门课就把选择这课程的学号的和课程id绑定在另一张表上
                 query.bindValue(":sid", Stu_id[i]);
            if(!query.exec())
            {
                QMessageBox::critical(this,"错误","填入课程号错误\n"
                                      ,QMessageBox::Ok,QMessageBox::NoButton);
                return;
            }
       }
   }

     Init();
     QMessageBox::information(this,"提示","全选成功\n"
                           ,QMessageBox::Ok,QMessageBox::NoButton);
}

choose::~choose()
{
    delete ui;
}
