#include "stusql.h"
#include<QSqlDatabase>   //连接数据库
#include<QDebug>
#include<QMessageBox>    //消息框
#include<QSqlError>
#include<QSqlQuery>
#include<QVariantList>
#include<QSqlRecord>

stusql::stusql(QObject *parent) : QObject(parent)
{
    //打印Qt支持的数据库驱动
    qDebug()<<QSqlDatabase::drivers();

    //获取数据库对象
    QSqlDatabase db=QSqlDatabase::addDatabase("QMYSQL");

    //配置数据库
    db.setHostName("localhost");
    db.setUserName("root");
    db.setPassword("1234");
    db.setDatabaseName("data");

    //打开数据库
    if(db.open()==false)
    {
        QMessageBox::warning(this,"失败",db.lastError().text());
        return;
    }

    //创建model对象
    model= new QSqlTableModel(this);
    //model存储数据库数
    //view 显示和修改数据

    //指定数据库
    model->setTable("student");

    //把model和view关联
    ui->tableView->setModel(model);



    //显示model里的数据
    model->select();

    //修改字段名
    model->setHeaderData(0,Qt::Horizontal,"学号");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"年龄");
    model->setHeaderData(3,Qt::Horizontal,"平时成绩");
    model->setHeaderData(4,Qt::Horizontal,"班级");
    model->setHeaderData(5,Qt::Horizontal,"学院");


    //修改model编辑模式
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);

    /*
    //设置view中的数据库不允许修改
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    */
}
