#include "teacher_choose.h"
#include "ui_teacher_choose.h"

teacher_choose::teacher_choose(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::teacher_choose)
{
    ui->setupUi(this);
    setWindowTitle("教师");
}

teacher_choose::~teacher_choose()
{
    delete ui;
}

void teacher_choose::on_sendhomeworkbutton_clicked()  //发布作业
{
    send_homework *Teacher_homework=new send_homework;
    Teacher_homework->show();
}

void teacher_choose::on_signinbutton_clicked()       //发布签到
{
    send_sign *Send_sign=new send_sign;
    Send_sign->show();
}

void teacher_choose::on_managebutton_clicked()
{
    teacher *Teacher=new teacher;
    Teacher->show();
}

void teacher_choose::on_markhomework_clicked()
{
    correct_homework *Correct_homework=new correct_homework;
    Correct_homework->show();
}

void teacher_choose::on_accountbutton_clicked()
{
    teacheraccount *Teacheraccount=new teacheraccount;
    Teacheraccount->show();
}

void teacher_choose::on_emailbutton_clicked()
{
    send_email_ts *Send_email_ts=new send_email_ts;
    Send_email_ts->show();
}

void teacher_choose::on_questionbutton_clicked()
{
     db=QSqlDatabase::addDatabase("QMYSQL");
     db.setHostName(DB_HOSTNAME);
     db.setDatabaseName(DB_NAME);
     db.setUserName(DB_USERNAME);
     db.setPassword(DB_PASSWORD);
     db.setPort(3306);
     if(!db.open())
     {
         QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

         return;
     }
     QSqlQuery query;
     query.prepare("SELECT id,name,identify FROM email_form WHERE id=:ID");
     query.bindValue(":ID",LoginId);
     query.exec();
     query.first();
     t_name =query.value("name").toString(); //根据学号获取姓名

     User users;
     users.id = LoginId;    //ID号
     users.name=t_name;

     QList<QHostAddress>list = QNetworkInterface::allAddresses();//获取本地主机的所有IP地址，并将其存储在list变量中
     foreach(QHostAddress address,list)
      {
         if(address.protocol() == QAbstractSocket::IPv4Protocol && address.toString()!="127.0.0.1")
             users.address =address.toString() ;//将IPv4地址保存在users结构体中的address成员变量中
      }

     question *Question;
     Question= new question(0,users);//使用UDP协议进行答疑聊天
     Question->show();    //答疑界面显示
}
