#include "page_login.h"
#include "ui_page_login.h"
#include <QDebug>

Page_login::Page_login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Page_login)
{
    ui->setupUi(this);//使用 UI 文件创建界面


    //设置标题
    setWindowTitle("登录");

    ui->adminbutton->setChecked(true);//默认选中管理员

    if(!database_connection())
    {
        QMessageBox::warning(this,"错误","打开数据库失败",QMessageBox::Ok,QMessageBox::NoButton);
    }
}

Page_login::~Page_login()
{
    delete ui;
}

void Page_login::on_registerbutton_clicked()  //注册
{
    account_register *Account_register=new account_register;
    Account_register->show();
}

void Page_login::on_loginbutton_clicked() //登录
{
    QString Id=ui->le_user->text();//输入用户名和密码
    QString Password=ui->le_password->text();
    //管理员登录
    if(ui->adminbutton->isChecked())
    {
        if(match_name_password(Id,Password,"admin"))
        {
            qDebug()<<"管理员登陆成功";
            QMessageBox::information(this, "提示", "管理员登陆成功");
            this->hide();
            admin *admin1=new admin;
            admin1->show();

        }
        else
            QMessageBox::information(this, "警告", "用户名或密码错误");
    }

    //教师登录
    if(ui->teachbutton->isChecked())
    {
        if(match_name_password(Id,Password,"teacher"))
         {
             LoginId=Id;
             qDebug()<<"教师登陆成功";
             QMessageBox::information(this, "提示", "老师登陆成功");

             this->hide();
             teacher_choose *Teacher=new teacher_choose;
             Teacher->show();

         }
         else
             QMessageBox::information(this, "警告", "用户名或密码错误");
    }

    //学生登录
    if(ui->studebutton->isChecked())
    {
        if(match_name_password(Id,Password,"student"))
        {
            LoginId=Id;
            qDebug()<<"学生登陆成功";
            QMessageBox::information(this, "提示", "学生登陆成功");
            this->hide();

            student *Student=new student;
            Student->show();
        }
        else
            QMessageBox::information(this, "警告", "用户名或密码错误");
    }
    emit sendLoginSuccess();
}

bool Page_login::database_connection()
{
    db=QSqlDatabase::addDatabase("QMYSQL");//指定数据库类型
    db.setHostName(DB_HOSTNAME);//主机名
    db.setDatabaseName(DB_NAME);//数据库名
    db.setUserName(DB_USERNAME);//用户名
    db.setPassword(DB_PASSWORD);//mysql密码
    db.setPort(3306); //指定端口号为3306
    if(db.open())
        return true;
    else
        return false;
}

bool Page_login::match_name_password(QString ID,QString PASSWORD,QString table) //匹配账号密码，如果正确返回true，否则返回false
{
    QString select="select id,password from ";//直接选两列出来
    QSqlQuery query(db);  //导入数据库

    query.exec(select+table);//向数据库输入命令
    bool flag=false;         //设置一个标志位，判断账号密码是否正确
    while(query.next())
    {
        QString id = query.value(0).toString();
        QString password = query.value(1).toString();  //选出来两列的第一列

        if(ID.compare(id)==0 && PASSWORD.compare(password)==0)
            flag=true;
    }
    return flag;
}





void Page_login::on_studebutton_toggled(bool checked)
{
    if(checked == true)
    {
        ui->le_user->setEnabled(1);//"1"为显示登录界面，"0"为锁定登录界面，下同
        ui->le_password->setEnabled(1);//显示注册界面
    }
    ui->widget->setStyleSheet("background-color: rgb(194, 241, 255);");//切换背景色
}

void Page_login::on_teachbutton_toggled(bool checked)
{
    if(checked == 1)
    {
        ui->le_user->setEnabled(1);//登录
        ui->le_password->setEnabled(1);//注册
    }
    ui->widget->setStyleSheet("background-color: rgb(255, 228, 222);");//切换背景色
}

void Page_login::on_adminbutton_toggled(bool checked)
{
    if(checked == true)
    {
        ui->le_user->setEnabled(1);//登录
        ui->le_password->setEnabled(1);//注册
    }
    ui->widget->setStyleSheet("background-color: rgb(225, 231, 255);");//切换背景色
}


