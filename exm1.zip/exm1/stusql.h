#ifndef STUSQL_H
#define STUSQL_H

#include <QObject>
#include <QSqlTableModel>
class stusql : public QObject
{
    Q_OBJECT
public:
    explicit stusql(QObject *parent = nullptr);

signals:


private:    QSqlTableModel *model;//模型

};

#endif // STUSQL_H
