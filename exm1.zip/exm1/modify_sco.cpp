#include "modify_sco.h"
#include "ui_modify_sco.h"

modify_sco::modify_sco(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::modify_sco)
{
    ui->setupUi(this);
    setWindowTitle("成绩修改");
    Init();
}

modify_sco::~modify_sco()
{
    delete ui;
}

void modify_sco::on_change_ok_clicked()
{

    if(ui->input_cid->text()==nullptr)
    {
        QMessageBox::critical(this,"错误","未填入课程号\n"
                              ,QMessageBox::Ok,QMessageBox::NoButton);
        Init();
        return;
    }
    QString _cid=ui->input_cid->text();//获取课程id:课程号

    if(ui->input_sid->text()==nullptr)
    {
        QMessageBox::critical(this,"错误","未填入学号\n"
                              ,QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    QString _sid=ui->input_sid->text();//获取学生id  :学号

    if(ui->input_grade->text()==nullptr)
    {
        QMessageBox::critical(this,"错误","未填入成绩\n"
                              ,QMessageBox::Ok,QMessageBox::NoButton);
        return;
    }
    QString _grade=ui->input_grade->text();//成绩获取  换算成绩点

    if(ui->Absence->text()==nullptr)
    {
        QMessageBox::critical(this,"错误","缺勤次数未填\n"
                              ,QMessageBox::Ok,QMessageBox::NoButton);
        Init();
        return;
    }
    QString _absence=ui->Absence->text();//获取课程id:课程号

    QString _credit;//绩点计算
    if(_grade.toInt()>=0 &&_grade.toInt()<60)
    {
        _credit="0.0";
    }else if(_grade.toInt()>=60 && _grade.toInt()<64)
    {
        _credit="1.0";
    }else if(_grade.toInt()>=64 && _grade.toInt()<68)
    {
        _credit="1.7";
    }else if(_grade.toInt()>=68 && _grade.toInt()<72)
    {
        _credit="2.0";
    }else if(_grade.toInt()>=72 && _grade.toInt()<75)
    {
        _credit="2.3";
    }else if(_grade.toInt()>=75 && _grade.toInt()<78)
    {
        _credit="2.7";
    }else if(_grade.toInt()>=78 && _grade.toInt()<82)
    {
        _credit="3.0";
    }else if(_grade.toInt()>=82 && _grade.toInt()<85)
    {
        _credit="3.3";
    }else if(_grade.toInt()>=85 && _grade.toInt()<90)
    {
        _credit="3.7";
    }else if(_grade.toInt()>=90 && _grade.toInt()<=100)
    {
        _credit="4.0";
    }
    else
    {
        QMessageBox::critical(this,"错误","填入成绩错误（0-100）\n"
                              ,QMessageBox::Ok,QMessageBox::NoButton);
        Init();
        return;
    }

    QSqlQuery query;

    query.prepare("Delete FROM scourse where sid=:sid and cid=:cid");//不同的课有不同的学号、但同一门课有同一个学号

    query.bindValue(":sid",_sid);
    query.bindValue(":cid",_cid);
    query.exec();
    query.prepare("INSERT INTO scourse (cid,sid, grade, credit,absence) "
                  "VALUES (:cid, :sid, :grade,:credit,:absence)");
    query.bindValue(":cid",_cid);
    query.bindValue(":sid",_sid);
    query.bindValue(":grade",_grade);
    query.bindValue(":credit",_credit);
    query.bindValue(":absence",_absence);
     if(!query.exec())
     {
         QMessageBox::critical(this,"错误","填入信息错误\n"
                               ,QMessageBox::Ok,QMessageBox::NoButton);
         Init();
         return;
     }

      QMessageBox::information(this,"提示","编辑完成\n"
                            ,QMessageBox::Ok,QMessageBox::NoButton);
}
void modify_sco::Init()
{

    db=QSqlDatabase::addDatabase("QMYSQL");

    db.setHostName(DB_HOSTNAME);
    db.setDatabaseName(DB_NAME);
    db.setUserName(DB_USERNAME);
    db.setPassword(DB_PASSWORD);
    db.setPort(3306);
    if(!db.open())
    {
        QMessageBox::warning(this,"错误","打开数据库失败,错误信息\n"
                             +db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);

        return;
    }
}
